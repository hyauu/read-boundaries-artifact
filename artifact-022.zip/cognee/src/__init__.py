"""Isolated Cognee coordination evaluation."""
