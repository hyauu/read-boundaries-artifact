"""Seal completed raw evidence, then score and checkpoint. Never touch runtime stores."""
from .common import *
from .content import score_attempt
def seal(out):
 out=Path(out);request=read(out/'REQUEST.json');result=read(out/'RESULT.json')
 assert result['execution']=='SEALED' and result['configuration_sha']==sha(out/'REQUEST.json')
 counters=read(out/'COUNTERS.json');assert counters['provider_denied']==0
 assert not (out/'network_guard.jsonl').exists() or not (out/'network_guard.jsonl').read_text().strip()
 files={p.relative_to(out).as_posix():sha(p) for p in out.rglob('*') if p.is_file() and 'runtime' not in p.relative_to(out).parts and p.name not in ['RAW_SEAL.json','COMPLETE.json','CONTENT_SCORES.json','SCORED_READS.json']}
 save(out/'RAW_SEAL.json',{'at':utc(),'files':files,'runtime_store_included':False,'note':'Raw API/backend/source receipts and full probes sealed; native store remains preserved separately.'})
 rows,index=score_attempt(out)
 initial=[r for r in rows if r['id']=='initial']
 if request['block'] not in ['SMOKE','CALIBRATION']:
  assert len(initial)==1 and initial[0]['usable_by_deadline'] and initial[0]['versions']==[0], 'HARNESS_INVALID initial source state'
 events=list(jsonlines(out/'events.jsonl'))
 if request['block'] in ['A','A_EXTRA']:
  assert any(e['event']=='schedule.release_reason' for e in events),'HARNESS_INVALID scheduler never released'
  if request['order']=='AR':assert any(e['event']=='schedule.read_held' for e in events)
  else:assert any(e['event']=='schedule.writer_first_change_held' for e in events)
 if request['block']=='C':
  expected=request['fault']=='INJECT'
  assert sum(e['event']=='injection.once' for e in events)==int(expected),'HARNESS_INVALID failure-point coverage'
  if expected:assert index.first_changes,'HARNESS_INVALID no completed mutation'
 if request['block']=='B':
  primary=[r for r in rows if r['category']=='primary']
  assert len(primary)==len(request['read_offsets_ns']),'HARNESS_INVALID dropped arrivals'
  assert all(r['enqueued_ns']>=r['target_ns'] and r['published_at_ns']>=r['target_ns'] for r in primary),'HARNESS_INVALID early action'
 if any(w.get('active_background_pipeline_tasks',0) for w in read(out/'WRITES.json')):raise RuntimeError('BOUNDARY_UNRESOLVED unexpected background writer')
 save(out/'COMPLETE.json',{'at':utc(),'kind':'NATIVE_RAW_SEALED_OFFLINE_SCORED','raw_seal_sha':sha(out/'RAW_SEAL.json'),'scored_sha':sha(out/'SCORED_READS.json'),'native_scores_sha':sha(out/'CONTENT_SCORES.json'),'configuration_sha':sha(out/'REQUEST.json'),'planned_id':request.get('id'),'mapping_errors':index.errors,'drain_exceeded':(out/'DRAIN_EXCEEDED.json').exists()})
 return rows
def verify(out):
 out=Path(out);c=read(out/'COMPLETE.json');assert c['raw_seal_sha']==sha(out/'RAW_SEAL.json') and c['scored_sha']==sha(out/'SCORED_READS.json') and c['native_scores_sha']==sha(out/'CONTENT_SCORES.json')
 for name,digest in read(out/'RAW_SEAL.json')['files'].items():assert sha(out/name)==digest,(out,name)
 return c
