"""Prespecified full-data endpoints and paired cluster bootstrap. Offline only."""
import argparse,csv,math,itertools
from collections import Counter,defaultdict
import numpy as np
from .common import *
from .seal import verify

POLICIES=['NATIVE','DOUBLE_READ','COORDINATED','EPOCH_VALIDATED']
ROLES=['passage','summary','graph_city','graph_company','fact_city','fact_company']
SERVICES=['RETURNED','NATIVE_ERROR','QUEUE_REJECTED','READ_DEADLINE','UNAVAILABLE_DIRTY','VALIDATION_EXHAUSTED','HARNESS_INVALID']
DRAW_COUNT=10000;BOOTSTRAP_SEED=2026101702

def csvwrite(path,rows):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 keys=list(dict.fromkeys(k for row in rows for k in row))
 with path.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
  for row in rows:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in row.items()})

def dist(out,name,values):
 xs=[float(x) for x in values if x is not None and math.isfinite(x)]
 out[name+'_n']=len(xs)
 for suffix,q in [('p25',.25),('p50',.5),('p75',.75),('p95',.95)]:out[name+'_'+suffix]=float(np.quantile(xs,q)) if xs else None
 out[name+'_mean']=float(np.mean(xs)) if xs else None

def ms(row,a,b):
 if a+'_ns' in row and b+'_ns' in row:return (row[b+'_ns']-row[a+'_ns'])/1e6
 return (row[b]-row[a])*1000 if a in row and b in row else None

def unit_metrics(cfg,rows,writes,native_scores,window,stage):
 mode=cfg['requested_mode'];n=len(rows);delivered=[r for r in rows if r['service']=='RETURNED'];known=[r for r in delivered if r.get('compatibility')!='UNKNOWN'];calls=[c for r in rows for c in r.get('native_calls',[])]
 u={'unit_id':cfg['id'],'block':cfg['block'],'seed':cfg['seed'],'strategy':cfg['strategy'],'requested_mode':mode,'stratum':cfg.get('order',cfg.get('profile',cfg.get('fault',''))),'stage':stage,'planned_requests':n,'delivered':len(delivered),'classifiable':len(known),'usable':sum(bool(r.get('usable_by_deadline')) for r in rows),'unknown':sum(r.get('compatibility')=='UNKNOWN' for r in delivered),'partial':sum(not r.get('coverage_complete',False) for r in delivered),'direct_conflicts':sum(bool(r.get('direct_conflict')) for r in delivered),'unrecognized_service':sum(r['service'] not in SERVICES for r in rows)}
 for status in SERVICES:u[status.lower()]=sum(r['service']==status for r in rows)
 for key in ['delivered','usable','unknown','partial','direct_conflicts']+[x.lower() for x in SERVICES if x!='RETURNED']:u[key+'_fraction']=u[key]/n if n else None
 u['conflict_among_classifiable']=u['direct_conflicts']/len(known) if known else None
 for role in ROLES:
  value=sum(bool(r.get('roles',{}).get(role)) for r in delivered);u['role_'+role]=value;u['role_'+role+'_fraction']=value/n if n else None
 u['native_calls']=len(calls);u['native_calls_per_planned']=len(calls)/n if n else None
 u['discarded_attempts']=sum(c.get('validation')=='DISCARDED' for c in calls);u['discarded_per_planned']=u['discarded_attempts']/n if n else None
 u['internal_conflicts_discarded']=sum(bool(native_scores.get(c['name'],{}).get('direct_conflict')) for c in calls if c.get('validation')=='DISCARDED')
 u['internal_errors_discarded']=sum(c['status']=='NATIVE_ERROR' and c.get('validation')=='DISCARDED' for c in calls)
 u['stable_native_errors']=sum(c.get('validation')=='STABLE_NATIVE_ERROR' for c in calls)
 u['response_bytes']=sum(c.get('response_bytes',0) for c in calls);u['response_bytes_per_planned']=u['response_bytes']/n if n else None
 u['late_results']=sum('late_status' in r for r in rows);u['late_fraction']=u['late_results']/n if n else None
 u['early_enqueues']=sum(r.get('enqueued_ns',0)<r.get('target_ns',0) for r in rows)
 u['negative_target_elapsed']=sum(r.get('published_at_ns',0)<r.get('target_ns',0) for r in rows)
 u['late_enqueues']=sum(r.get('enqueued_ns',0)>r.get('target_ns',0) for r in rows)
 for key,chosen,a,b in [('logical_ms',rows,'target_arrival','published_at'),('delivered_ms',delivered,'target_arrival','published_at'),('enqueue_delivered_ms',delivered,'enqueued','published_at'),('enqueue_logical_ms',rows,'enqueued','published_at'),('arrival_late_ms',rows,'target_arrival','enqueued'),('queue_ms',rows,'enqueued','dispatcher_start'),('gate_ms',rows,'lease_requested','lease_acquired'),('validation_ms',rows,'validation_start','validation_end')]:dist(u,key,[ms(r,a,b) for r in chosen])
 dist(u,'native_ms',[sum(ms(c,'started','ended') or 0 for c in r.get('native_calls',[])) for r in rows if r.get('native_calls')])
 dist(u,'attempts',[len(r.get('native_calls',[])) for r in rows])
 dist(u,'epoch_wait_ms',[r.get('epoch_wait_ns',0)/1e6 for r in rows if r['strategy']=='EPOCH_VALIDATED'])
 u['freshness_unknown']=sum(r.get('lag_at_return') is None for r in delivered)
 for endpoint in ['start','return']:
  lags=[r['lag_at_'+endpoint] for r in delivered if r.get('lag_at_'+endpoint) is not None]
  u['freshness_known_'+endpoint]=len(lags);u['stale_'+endpoint]=sum(x>0 for x in lags);u['stale_'+endpoint+'_fraction']=sum(x>0 for x in lags)/len(lags) if lags else None
  u['ahead_success_head_'+endpoint]=sum(x<0 for x in lags)
 if window:
  end=window.get('end_ns',round(window['end']*1e9));start=window.get('start_ns',round(window['start']*1e9))
  u['returned_in_window']=sum(r['published_at_ns']<=end for r in delivered);u['returned_in_drain']=len(delivered)-u['returned_in_window'];u['usable_in_window']=sum(r.get('usable_by_deadline') and r['published_at_ns']<=end for r in rows);u['completed_by_window_per_second']=u['returned_in_window']/((end-start)/1e9)
 u['update_requests']=len(writes);u['updates_success']=sum(bool(w.get('native_success')) for w in writes);u['updates_failed']=sum(w['service']=='UPDATE_FAILED' for w in writes);u['updates_deadline']=sum(w['service']=='UPDATE_DEADLINE' for w in writes)
 u['updates_success_fraction']=u['updates_success']/len(writes) if writes else None
 for name,a,b in [('writer_queue_ms','writer_queued','driver_acquired'),('writer_gate_ms','writer_gate_requested','writer_gate_acquired'),('update_body_ms','body_start','body_end'),('update_total_ms','target_arrival','terminated')]:dist(u,name,[ms(w,a,b) for w in writes])
 return u

def contrast(items_a,items_b,metrics,base,planned):
 out=[]
 for metric in metrics:
  seeds=sorted(set(items_a)&set(items_b));pairs=[(items_a[s].get(metric),items_b[s].get(metric)) for s in seeds if items_a[s].get(metric) is not None and items_b[s].get(metric) is not None]
  record={**base,'metric':metric,'planned_clusters':planned,'paired_clusters':len(pairs),'missing_paired_clusters':planned-len(pairs),'draws':DRAW_COUNT,'bootstrap_seed':BOOTSTRAP_SEED,'ci_level':.95}
  if not pairs:out.append({**record,'mean_difference':None,'ci_low':None,'ci_high':None});continue
  arr=np.asarray(pairs,float);delta=arr[:,0]-arr[:,1];rng=np.random.default_rng(BOOTSTRAP_SEED);draws=rng.integers(0,len(delta),(DRAW_COUNT,len(delta)));boot=delta[draws].mean(axis=1)
  record.update(mean_a=float(arr[:,0].mean()),mean_b=float(arr[:,1].mean()),mean_difference=float(delta.mean()),paired_delta_median=float(np.median(delta)),ci_low=float(np.quantile(boot,.025)),ci_high=float(np.quantile(boot,.975)),zero_event_or_degenerate=bool(np.all(delta==delta[0])))
  ratios=np.asarray([a/b for a,b in pairs if a>0 and b>0]);record['positive_ratio_pairs']=len(ratios)
  if len(ratios):
   rng=np.random.default_rng(BOOTSTRAP_SEED);rb=ratios[rng.integers(0,len(ratios),(DRAW_COUNT,len(ratios)))].mean(axis=1)
   record.update(mean_pair_ratio=float(ratios.mean()),ratio_ci_low=float(np.quantile(rb,.025)),ratio_ci_high=float(np.quantile(rb,.975)))
  out.append(record)
 return out

METRICS=['usable_fraction','delivered_fraction','direct_conflicts_fraction','conflict_among_classifiable','unknown_fraction','partial_fraction','native_error_fraction','queue_rejected_fraction','read_deadline_fraction','unavailable_dirty_fraction','validation_exhausted_fraction','native_calls_per_planned','discarded_per_planned','response_bytes_per_planned','late_fraction','updates_success_fraction','stale_start_fraction','stale_return_fraction']+['role_'+r+'_fraction' for r in ROLES]+[x+'_'+q for x in ['delivered_ms','enqueue_delivered_ms','arrival_late_ms','queue_ms','gate_ms','native_ms','validation_ms','epoch_wait_ms','attempts','writer_queue_ms','writer_gate_ms','update_body_ms','update_total_ms'] for q in ['p50','p95']]

def comparisons(units):
 groups=defaultdict(list);out=[]
 for u in units:groups[(u['block'],u['requested_mode'],u['stratum'],u['stage'])].append(u)
 for (block,mode,stratum,stage),rows in sorted(groups.items()):
  by={p:{u['seed']:u for u in rows if u['strategy']==p} for p in POLICIES}
  for a,b in itertools.combinations(POLICIES,2):
   # Orient all contrasts consistently, emphasizing Epoch and Coordination.
   a,b=b,a
   out+=contrast(by[a],by[b],METRICS,{'kind':'POLICY','block':block,'requested_mode':mode,'stratum':stratum,'stage':stage,'comparison':a+' - '+b},20 if block=='A' else 10)
 modegroups=defaultdict(list)
 for u in units:
  if u['requested_mode'] in ['DEFAULT_REQUEST','FORCED_FULL']:modegroups[(u['block'],u['stratum'],u['stage'],u['strategy'])].append(u)
 for (block,stratum,stage,policy),rows in sorted(modegroups.items()):
  if block not in ['A','B']:continue
  a={u['seed']:u for u in rows if u['requested_mode']=='DEFAULT_REQUEST'};b={u['seed']:u for u in rows if u['requested_mode']=='FORCED_FULL'}
  out+=contrast(a,b,METRICS,{'kind':'REQUEST_MODE','block':block,'strategy':policy,'stratum':stratum,'stage':stage,'comparison':'DEFAULT_REQUEST - FORCED_FULL'},20 if block=='A' else 10)
 return out

def aggregate(units):
 groups=defaultdict(list);out=[]
 for u in units:groups[(u['block'],u['requested_mode'],u['stratum'],u['stage'],u['strategy'])].append(u)
 for key,rows in sorted(groups.items()):
  r=dict(zip(['block','requested_mode','stratum','stage','strategy'],key));r['runs_or_histories']=len(rows)
  for k in ['planned_requests','delivered','usable','classifiable','direct_conflicts','partial','unknown','native_calls','discarded_attempts','internal_conflicts_discarded','internal_errors_discarded','early_enqueues','negative_target_elapsed','late_enqueues','update_requests','updates_success','updates_failed','updates_deadline']+[x.lower() for x in SERVICES]+['role_'+x for x in ROLES]:r[k]=sum(u.get(k,0) for u in rows)
  for metric in METRICS:dist(r,metric+'_across_runs',[u.get(metric) for u in rows])
  out.append(r)
 return out

def main():
 manifest=read(ROOT/'RUN_MANIFEST.json');cp=read(ROOT/'CHECKPOINT.json')['completed'];assert len(cp)==manifest['planned'],'Only run full offline analysis after all planned units are accounted for'
 dest=ROOT/'analysis/final';allreads=[];allwrites=[];units=[];native_attempts=[];paths=[];missing=[];costs=[]
 for entry in manifest['units']:
  record=cp[entry['id']]
  if record.get('execution')=='NOT_APPLICABLE':missing.append(record);continue
  p=ROOT/record['attempt'];verify(p);cfg=read(p/'REQUEST.json');rows=read(p/'SCORED_READS.json');writes=read(p/'WRITES.json');scores=read(p/'CONTENT_SCORES.json');window=read(p/'WINDOW.json') if (p/'WINDOW.json').exists() else None
  identity={k:cfg.get(k) for k in ['id','block','seed','strategy','requested_mode','order','profile','fault']};identity['unit_id']=identity.pop('id')
  for r in rows:
   calls=r.get('native_calls',[]);row={**identity,**{k:v for k,v in r.items() if k!='native_calls'},'native_call_count':len(calls),'epoch_discarded':sum(c.get('validation')=='DISCARDED' for c in calls)};allreads.append(row)
   for call in calls:native_attempts.append({**identity,'logical_id':r['id'],'category':r['category'],**call,'score':scores.get(call['name'])})
  for w in writes:
   row={**identity,**w};observed=(w.get('canonical_after') or {}).get('text');target=(w.get('arguments') or {}).get('data')
   row['target_content_observed']=observed==target if observed is not None and target is not None else None
   row['unexpected_noop']=(observed!=target) if w.get('returned_status')=='unchanged' and observed is not None and target is not None else (None if w.get('returned_status')=='unchanged' else False)
   allwrites.append(row);paths.append({**identity,**{k:row.get(k) for k in ['id','requested_mode','arguments','branch_entered','returned_status','fallback_reason','fallback_detail','changed_reused_chunk_counts','native_success','unexpected_noop','service','error']}})
  stages=['post_attempt','post_recovery'] if cfg['block']=='C' else ['primary']
  for stage in stages:units.append(unit_metrics(cfg,[r for r in rows if r['category']==stage],[w for w in writes if bool(w.get('recovery'))==(stage=='post_recovery')] if cfg['block']=='C' else writes,scores,window,stage))
  count=Counter();pending={}
  for e in jsonlines(p/'events.jsonl'):
   if e['event']=='backend.request':
    pending[e['seq']]=(e['backend'],e['method']);count[(e['event'],e['backend'],e['method'])]+=1
   elif e['event'] in ['backend.response','backend.error']:
    backend,method=pending[e['request_seq']];count[(e['event'],backend,method)]+=1
   elif e['event'].startswith('fixture.'):count[(e['event'],'deterministic_fixture','call')]+=1
  costs.extend({**identity,'event':k[0],'backend':k[1],'method':k[2],'count':v} for k,v in count.items())
 for name,rows in [('read_requests',allreads),('update_requests',allwrites),('unit_metrics',units),('native_attempts',native_attempts),('update_paths',paths),('operation_costs',costs),('paired_comparisons',comparisons(units)),('group_summary',aggregate(units))]:csvwrite(dest/(name+'.csv'),rows)
 assert not any(u['early_enqueues'] or u['negative_target_elapsed'] for u in units),'Driver validity failure, never clamp or reinterpret'
 save(dest/'SUMMARY.json',{'at':utc(),'planned':manifest['planned'],'accounted':len(cp),'accepted':len(cp)-len(missing),'not_applicable':missing,'logical_reads_all_categories':len(allreads),'units_or_stages':len(units),'update_operations':len(allwrites),'native_attempts':len(native_attempts),'path_composition':dict(Counter((str(p['returned_status'])+' / '+str(p['fallback_reason'])) for p in paths)),'driver':'no_early_dispatch_verified','seed':BOOTSTRAP_SEED,'draws':DRAW_COUNT,'implementation_frozen_sha':sha(Path(__file__)),'scope':'Five service/content endpoints, six policy contrasts and mode contrasts. B0 shared pure-read runs counted once; no pooling of requests as independent runs. Intervals descriptive; no global multiplicity correction or equivalence claim.'})
 print(json.dumps({'accepted':len(cp)-len(missing),'logical_reads':len(allreads)}))

if __name__=='__main__':main()
