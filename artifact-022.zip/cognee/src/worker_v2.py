"""Fresh native process/store. Corrected open arrivals, full candidate receipts."""
import argparse,asyncio,contextlib,traceback
from .common import *
from .clock import now_ns,wait_until_ns
from .native import Session

async def wait_event(event,seconds=60):await asyncio.wait_for(event.wait(),seconds)

async def controlled(s,c):
 h=s.hooks;h.kind=c['order'];h.target_read='primary.n1';h.target_write='update_v1'
 if h.kind=='AR':
  reading=asyncio.create_task(s.read('primary',deadline=90));await wait_event(h.read_reached)
  writing=asyncio.create_task(s.update('update_v1',1,deadline=90))
  if s.strategy=='COORDINATED':
   async def waiting():
    while not s.gate.waiting_writers:await asyncio.sleep(.001)
   await asyncio.wait_for(waiting(),10);s.observer.emit('schedule.release_reason',reason='writer_waiting_for_existing_reader');h.release_read.set()
   await reading;h.release_write.set();await writing
  else:
   await wait_event(h.write_reached);h.release_read.set()
   if s.strategy=='EPOCH_VALIDATED':
    a=asyncio.create_task(s.epoch.invalidated.wait());b=asyncio.create_task(s.epoch.waiting.wait())
    done,pending=await asyncio.wait([a,b,reading],timeout=10,return_when=asyncio.FIRST_COMPLETED);assert done,'Epoch controlled schedule did not reach release condition'
    for task in pending:
     if task is not reading:task.cancel()
    reason='epoch_invalidated_or_waiting_for_stable'
   else:
    try:await asyncio.wait_for(asyncio.shield(reading),.5);reason='logical_read_terminated'
    except asyncio.TimeoutError:reason='native_read_still_active_at_fixed_observation_bound'
   s.observer.emit('schedule.release_reason',reason=reason);h.release_write.set();await asyncio.gather(writing,reading)
 else:
  writing=asyncio.create_task(s.update('update_v1',1,deadline=90));await wait_event(h.write_reached)
  reading=asyncio.create_task(s.read('primary',deadline=90))
  if s.strategy=='EPOCH_VALIDATED':
   waiting=asyncio.create_task(s.epoch.waiting.wait());await asyncio.wait([waiting,reading],timeout=.5,return_when=asyncio.FIRST_COMPLETED)
   if not waiting.done():waiting.cancel()
   reason='epoch_waiting_for_stable' if s.epoch.waiting.is_set() else 'fixed_observation_bound'
  else:
   try:await asyncio.wait_for(asyncio.shield(reading),.5);reason='logical_read_terminated'
   except asyncio.TimeoutError:reason='read_admission_or_native_wait_at_fixed_bound'
  s.observer.emit('schedule.release_reason',reason=reason);h.release_write.set();await asyncio.gather(writing,reading)
 h.kind=None;await s.read('quiescent',category='validation');await s.probe('quiescent')

async def workload(s,c):
 p=c['parameters'];deadline=p['read_deadline']
 for i in range(10):await s.read(f'warmup_{i}',category='warmup',deadline=deadline)
 t0=now_ns();end=t0+round(p['duration']*1e9);queue=asyncio.Queue(maxsize=p['pending_capacity']);active={}
 def state(event,**kw):s.observer.emit(event,pending_depth=queue.qsize(),active_slots=dict(active),**kw)
 async def consume(slot):
  while True:
   item=await queue.get()
   try:
    if item is None:return
    name,target,enqueued=item;active[slot]=name;state('driver.slot_acquired',slot=slot,read_id=name)
    try:await s.read(name,arrival_ns=target,deadline=deadline,enqueued_ns=enqueued,slot=slot)
    finally:active.pop(slot,None);state('driver.slot_released',slot=slot,read_id=name)
   finally:queue.task_done()
 consumers=[asyncio.create_task(consume(i)) for i in range(p['read_slots'])]
 async def writer():
  tasks=[]
  for i,offset in enumerate(c['update_offsets_ns'],1):
   target=t0+offset;await wait_until_ns(target);tasks.append(asyncio.create_task(s.update(f'update_v{i}',i,arrival_ns=target,deadline=p['update_deadline'])))
  if tasks:await asyncio.gather(*tasks)
 writing=asyncio.create_task(writer())
 for i,offset in enumerate(c['read_offsets_ns']):
  target=t0+offset;await wait_until_ns(target);name=f'read_{i:05d}';enqueued=now_ns();assert enqueued>=target,'EARLY_DISPATCH'
  try:queue.put_nowait((name,target,enqueued));state('driver.enqueued',read_id=name,target_ns=target,actual_enqueue_ns=enqueued)
  except asyncio.QueueFull:
   published=now_ns();due=target+round(deadline*1e9)
   row={'id':name,'category':'primary','target_ns':target,'target_arrival_ns':target,'target_arrival':target/1e9,'actual_enqueue_ns':enqueued,'enqueued_ns':enqueued,'enqueued':enqueued/1e9,'deadline_ns':due,'deadline_at':due/1e9,'response_published_ns':published,'published_at_ns':published,'published_at':published/1e9,'strategy':s.strategy,'service':'QUEUE_REJECTED','native_calls':[]}
   assert published>=enqueued>=target;s.reads.append(row);state('logical.queue_rejected',record=row)
 await wait_until_ns(end);state('window.closed',start_ns=t0,end_ns=end)
 draining=asyncio.gather(queue.join(),writing);done,_=await asyncio.wait([draining],timeout=p['drain_limit'])
 if not done:
  save(s.out/'DRAIN_EXCEEDED.json',{'at':utc(),'limit':p['drain_limit'],'native_tasks_not_cancelled':True});await s.gate.dirty('fixed drain cap exceeded');await s.epoch.dirty('fixed drain cap exceeded');await draining
 for _ in consumers:queue.put_nowait(None)
 await asyncio.gather(*consumers)
 save(s.out/'WINDOW.json',{'start_ns':t0,'end_ns':end,'start':t0/1e9,'end':end/1e9,'drain_ended_ns':now_ns(),'planned_reads':len(c['read_offsets_ns']),'planned_updates':len(c['update_offsets_ns'])})
 await s.read('quiescent',category='validation',deadline=deadline);await s.probe('quiescent')

async def fault(s,c):
 h=s.hooks;h.target_write='update_v1';h.fault=c['fault']=='INJECT';p=c['parameters']
 first=await s.update('update_v1',1,deadline=p['update_deadline']);zero=first['terminated_ns'];tasks=[]
 for i,offset in enumerate([0,1,2,4,8]):
  target=zero+offset*10**9;await wait_until_ns(target);tasks.append(asyncio.create_task(s.read(f'post_{i}',arrival_ns=target,deadline=p['read_deadline'],category='post_attempt')))
 target=zero+15*10**9;await wait_until_ns(target);recovery=await s.update('recovery_v1',1,arrival_ns=target,deadline=p['update_deadline'],recovery=True)
 await asyncio.gather(*tasks);await s.probe('post_recovery')
 for i in range(5):await s.read(f'recovered_{i}',deadline=p['read_deadline'],category='post_recovery')
 save(s.out/'FAILURE_WINDOW.json',{'termination_zero_ns':zero,'scripted_recovery_arrival_ns':target,'recovery_record':recovery,'fault_injected':c['fault']=='INJECT','injection_reached':h.first_change})

async def execute(config,out):
 s=Session(out,config['strategy'],config.get('requested_mode','FORCED_FULL'));save(out/'REQUEST.json',config)
 try:
  await s.open();await s.read('initial',category='validation');await s.probe('initial')
  if config['block']=='A':await controlled(s,config)
  elif config['block']=='B':await workload(s,config)
  elif config['block']=='C':await fault(s,config)
  elif config['block']=='SMOKE':
   await asyncio.gather(s.read('parallel_1',category='engineering'),s.read('parallel_2',category='engineering'));await s.update('update_v1',1);await s.read('updated',category='validation');await s.probe('updated')
  else:raise ValueError(config['block'])
  await s.close()
  if s.observer.counts['provider.denied']:raise RuntimeError('Forbidden provider path')
  save(out/'RESULT.json',{'execution':'SEALED','at':utc(),'configuration_sha':sha(out/'REQUEST.json'),'health':s.epoch.health if s.strategy=='EPOCH_VALIDATED' else s.gate.state,'epoch_health':s.epoch.health})
 except BaseException as exc:
  s.hooks.release();save(out/'FAILURE.json',{'at':utc(),'type':type(exc).__name__,'error':repr(exc),'traceback':traceback.format_exc()})
  with contextlib.suppress(BaseException):await asyncio.wait_for(s.close(),30)
  raise

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--out',required=True);a=p.parse_args()
 out=Path(a.out).resolve();assert out.is_relative_to(ROOT.resolve());out.mkdir(parents=True,exist_ok=False);asyncio.run(execute(read(a.config),out))
