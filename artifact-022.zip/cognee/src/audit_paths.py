"""Compare selected actual imported sources with the retained fixed Git tree."""
import ast,shutil
from .common import *

FILES=['api/v1/update/update.py','api/v1/update/incremental.py','api/v1/update/result.py','api/v1/update/routers/get_update_router.py','modules/data/methods/publish_updated_data.py','modules/retrieval/hybrid_retriever.py','modules/pipelines/layers/pipeline_execution_mode.py','modules/pipelines/operations/pipeline.py','infrastructure/databases/unified/provenance_delete_planner.py','infrastructure/databases/graph/ladybug/adapter.py','infrastructure/databases/graph/get_graph_engine.py','infrastructure/databases/vector/lancedb/LanceDBAdapter.py','context_global_variables.py']
def main():
 old=PROJECT/'replication';tree={x['path']:x['sha'] for x in read(old/'sources/tree.json')['tree'] if x['type']=='blob'};rows=[]
 for rel in FILES:
  relative='cognee/'+rel;retained=old/'sources/cognee'/relative;actual=old/'.venv/Lib/site-packages'/relative
  data=actual.read_bytes();assert data==retained.read_bytes();blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert blob==tree[relative]
  copy=ROOT/'inputs/pinned_sources'/relative;copy.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(actual,copy)
  text=data.decode('utf-8');matches=[{'line':i,'text':line.strip()} for i,line in enumerate(text.splitlines(),1) if any(t in line for t in ['chunk_level_diff:','incremental_update(','_run_incremental_update(','_write_and_publish(','publish_updated_data(','status="','supports_incremental_chunk_updates','supports_payload_update','_BACKGROUND_PIPELINE_TASKS','async def close','shutdown(wait=True)','_submit_to_executor_locked'])]
  rows.append({'relative_path':relative,'actual_import_file':str(actual),'retained_file':str(retained),'sha256':sha(actual),'git_blob_sha1':blob,'matching_source_pin':True,'selected_lines':matches})
 save(ROOT/'configs/SOURCE_INTEGRITY.json',{'at':utc(),'commit':'ba3631f2ed363a6ea50d649c34c56885af6b36fe','selected_imported_files_verified':len(rows),'all_selected_files_match_retained_git_blobs':True,'files':rows,'prior_full_source_verification':str(PROJECT/'cognee_coordination_full_v1/configs/SOURCE_INTEGRITY.json'),'note':'Targeted actual-source verification, not an online tag upgrade or a new complete dependency audit.'})
 print(json.dumps({'verified_selected_actual_sources':len(rows)}))

if __name__=='__main__':main()
