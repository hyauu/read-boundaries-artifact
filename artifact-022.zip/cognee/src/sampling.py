"""Pre-formal sampling implementation, run only on sealed final evidence."""
from collections import defaultdict
from .common import *
POLICIES=['NATIVE','DOUBLE_READ','COORDINATED','EPOCH_VALIDATED']

def total_wait_ns(row):
 enqueue=row.get('enqueued_ns',row['target_ns']);dispatch=row.get('dispatcher_start_ns',enqueue)
 gate=row.get('lease_acquired_ns',row.get('lease_requested_ns',0))-row.get('lease_requested_ns',0)
 return dispatch-enqueue+gate+row.get('epoch_wait_ns',0)

def select(configured):
 reasons=defaultdict(lambda:defaultdict(list));b=defaultdict(list)
 def add(uid,rid,reason):
  if reason not in reasons[uid][rid]:reasons[uid][rid].append(reason)
 for cfg,rows in configured:
  uid=cfg['id'];block=cfg['block']
  if block=='A' and cfg['seed'] in [73001,73002] or block=='C' and cfg['seed'] in [75001,75002]:
   for r in rows:add(uid,r['id'],'lowest_two_histories_all_planned_cases')
  if block=='B':
   b[(cfg['requested_mode'],cfg['strategy'],cfg['profile'])].extend((cfg['seed'],uid,r) for r in rows if r['category']=='primary')
 for key,items in sorted(b.items()):
  items.sort(key=lambda x:(x[0],x[2]['id'],x[1]));first={}
  if key[2]=='UPDATE_BURST':
   lowest=items[0][0];run=[x for x in items if x[0]==lowest]
   for _,uid,r in [run[0],run[-1]]:add(uid,r['id'],'representative_lowest_seed_burst_endpoints')
   origin=min(x[2]['target_ns'] for x in run)
   for _,uid,r in run:
    if 20_500_000_000<=r['target_ns']-origin<=24_000_000_000:add(uid,r['id'],'representative_lowest_seed_fixed_burst_interval_20.5_to_24s')
  for seed,uid,r in items:
   tags=[]
   if r.get('usable_by_deadline'):tags.append('normal_complete')
   if r['service']!='RETURNED':tags.append('caller:'+r['service']+':'+str(r.get('error','')).split('(',1)[0])
   if r['service']=='RETURNED' and not r.get('coverage_complete',False):tags.append('partial:'+json.dumps(r.get('roles'),sort_keys=True)+':'+str(r.get('compatibility')))
   calls=r.get('native_calls',[])
   if sum(c.get('validation')=='DISCARDED' for c in calls)>=2:tags.append('epoch_repeated_invalidation')
   if any(c.get('validation')=='STABLE_NATIVE_ERROR' for c in calls):tags.append('epoch_stable_error')
   for tag in tags:
    if tag not in first:first[tag]=(uid,r['id']);add(uid,r['id'],'first_by_seed_read:'+tag)
  for tag,function in [('directed_max_arrival_late',lambda r:r.get('enqueued_ns',r['target_ns'])-r['target_ns']),('directed_max_total_wait',total_wait_ns)]:
   _,uid,r=max(items,key=lambda x:function(x[2]));add(uid,r['id'],tag)
 # Pair every selected primary B request by same requested mode/profile/seed.
 lookup={(c['requested_mode'],c.get('profile'),c['seed'],c['strategy']):(c,rs) for c,rs in configured if c['block']=='B'}
 for cfg,rows in configured:
  if cfg['block']!='B' or cfg['id'] not in reasons:continue
  selected=list(reasons[cfg['id']])
  for policy in POLICIES:
   paired,pr=lookup[(cfg['requested_mode'],cfg['profile'],cfg['seed'],policy)]
   valid={r['id'] for r in pr}
   for rid in selected:
    assert rid in valid;add(paired['id'],rid,'paired_same_request')
 for cfg,rows in configured:
  if cfg['block']=='B' and cfg['id'] in reasons:
   for r in rows:
    if r['category'] in ['validation','warmup']:add(cfg['id'],r['id'],'initial_quiescent_warmup_context')
 return {uid:dict(sorted(rs.items())) for uid,rs in sorted(reasons.items())}
