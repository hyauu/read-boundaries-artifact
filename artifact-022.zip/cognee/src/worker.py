"""One native owner/process per fresh attempt. No shared old database."""
import argparse,asyncio,contextlib,statistics,time,traceback
from .common import *
from .native import Session,rt,source

async def wait_event(event,seconds=60):await asyncio.wait_for(event.wait(),seconds)
async def controlled(s,config):
 h=s.hooks;h.kind=config['order'];h.target_read='primary.n1';h.target_write='update_v1'
 if h.kind=='AR':
  reading=asyncio.create_task(s.read('primary',deadline=90))
  await wait_event(h.read_reached)
  writing=asyncio.create_task(s.update('update_v1',1,deadline=90))
  if s.strategy=='COORDINATED':
   async def wait_writer():
    while not s.gate.waiting_writers:await asyncio.sleep(.001)
   await asyncio.wait_for(wait_writer(),10)
   s.observer.emit('schedule.release_reason',reason='writer_waiting_for_existing_read_lease');h.release_read.set()
   await reading;h.release_write.set();await writing
  else:
   await wait_event(h.write_reached);s.observer.emit('schedule.release_reason',reason='new_graph_before_edge_vectors');h.release_read.set()
   try:await asyncio.wait_for(asyncio.shield(reading),.5)
   except asyncio.TimeoutError:s.observer.emit('schedule.release_reason',reason='native_read_still_active_at_fixed_observation_bound')
   finally:h.release_write.set()
   await writing;await reading
 else:
  writing=asyncio.create_task(s.update('update_v1',1,deadline=90));await wait_event(h.write_reached)
  reading=asyncio.create_task(s.read('primary',deadline=90))
  try:
   await asyncio.wait_for(asyncio.shield(reading),.5);reason='logical_read_terminated'
  except asyncio.TimeoutError:
   reason='coordinated_admission_wait' if s.strategy=='COORDINATED' else 'native_read_still_active_at_fixed_observation_bound'
  s.observer.emit('schedule.release_reason',reason=reason);h.release_write.set()
  await asyncio.gather(writing,reading)
 h.kind=None
 await s.read('quiescent',category='validation')
 await s.probe('quiescent')

async def workload(s,config):
 p=config['parameters'];D=p['duration'];deadline=p['read_deadline']
 for i in range(10):await s.read(f'warmup_{i}',category='warmup',deadline=deadline)
 t0=time.perf_counter();queue=asyncio.Queue(maxsize=64)
 async def consume():
  while True:
   item=await queue.get()
   try:
    if item is None:return
    name,arrival,enqueued=item
    await s.read(name,arrival,deadline,enqueued=enqueued)
   finally:queue.task_done()
 consumers=[asyncio.create_task(consume()) for _ in range(4)]
 async def writer():
  tasks=[]
  for i,at in enumerate(config['update_arrivals'],1):
   await asyncio.sleep(max(0,t0+at-time.perf_counter()))
   tasks.append(asyncio.create_task(s.update(f'update_v{i}',i,arrival=t0+at,deadline=p['update_deadline'])))
  if tasks:await asyncio.gather(*tasks)
 writing=asyncio.create_task(writer())
 for i,at in enumerate(config['read_arrivals']):
  await asyncio.sleep(max(0,t0+at-time.perf_counter()));enqueued=time.perf_counter();name=f'read_{i:05d}'
  try:queue.put_nowait((name,t0+at,enqueued))
  except asyncio.QueueFull:
   row={'id':name,'category':'primary','target_arrival':t0+at,'enqueued':enqueued,'deadline_at':t0+at+deadline,'published_at':time.perf_counter(),'strategy':s.strategy,'service':'QUEUE_REJECTED','native_calls':[]}
   s.reads.append(row);s.observer.emit('logical.queue_rejected',record=row)
 await asyncio.sleep(max(0,t0+D-time.perf_counter()));s.observer.emit('window.closed',t0=t0,D=D)
 draining=asyncio.gather(queue.join(),writing)
 done,_=await asyncio.wait([draining],timeout=p['drain_limit'])
 if not done:
  save(s.out/'DRAIN_EXCEEDED.json',{'at':utc(),'limit':p['drain_limit'],'health':'QUARANTINED','native_tasks_not_cancelled':True})
  await s.gate.dirty('fixed drain cap exceeded; scope quarantined')
  # Preserve actual work and its receipts; the run's service window stays closed.
  await draining
 for _ in consumers:queue.put_nowait(None)
 await asyncio.gather(*consumers)
 save(s.out/'WINDOW.json',{'start':t0,'end':t0+D,'drain_ended':time.perf_counter(),'planned_reads':len(config['read_arrivals']),'planned_updates':len(config['update_arrivals'])})
 await s.read('quiescent',category='validation',deadline=deadline);await s.probe('quiescent')

async def fault(s,config):
 h=s.hooks;h.target_write='update_v1';h.fault=config['fault']=='INJECT'
 first=await s.update('update_v1',1,deadline=config['parameters']['update_deadline']);t0=first['terminated']
 tasks=[]
 for i,at in enumerate([0,1,2,4,8]):
  await asyncio.sleep(max(0,t0+at-time.perf_counter()));tasks.append(asyncio.create_task(s.read(f'post_{i}',arrival=t0+at,deadline=config['parameters']['read_deadline'],category='post_attempt')))
 await asyncio.sleep(max(0,t0+15-time.perf_counter()))
 recovery=await s.update('recovery_v1',1,arrival=t0+15,deadline=config['parameters']['update_deadline'],recovery=True)
 await asyncio.gather(*tasks)
 # Same native retry for both fault and no-fault units, even if the prior attempt succeeded.
 await s.probe('post_recovery')
 for i in range(5):await s.read(f'recovered_{i}',deadline=config['parameters']['read_deadline'],category='post_recovery')
 save(s.out/'FAILURE_WINDOW.json',{'termination_zero':t0,'scripted_recovery_arrival':t0+15,'recovery_record':recovery,'fault_injected':config['fault']=='INJECT','injection_reached':h.first_change})

async def calibration(s):
 reads=[];updates=[]
 # Exactly20 native timing reads and3 successful update timings; setup/probes separately marked.
 for i in range(20):
  row=await s.read(f'calibrate_read_{i}',category='calibration');assert row['service']=='RETURNED',row
  call=row['native_calls'][0];reads.append(call['ended']-call['started'])
 for i in range(1,4):
  row=await s.update(f'calibrate_update_{i}',i);assert row['service']=='SUCCESS',row
  updates.append(row['body_end']-row['body_start'])
 save(s.out/'CALIBRATION.json',{'read_seconds':reads,'update_seconds':updates,'r':statistics.median(reads),'u':statistics.median(updates),'native_reads':20,'successful_updates':3,'latency_only_not_effect_selection':True})
 await s.probe('calibration_final')

async def execute(config,out):
 s=Session(out,config.get('strategy','NATIVE'));save(out/'REQUEST.json',config)
 try:
  await s.open()
  if config['block'] not in ['CALIBRATION','SMOKE']:
   await s.read('initial',category='validation')
   await s.probe('initial')
  if config['block']=='CALIBRATION':await calibration(s)
  elif config['block'] in ['A','A_EXTRA']:await controlled(s,config)
  elif config['block']=='B':await workload(s,config)
  elif config['block']=='C':await fault(s,config)
  elif config['block']=='SMOKE':
   await s.read('initial',category='validation');await s.probe('initial')
   await asyncio.gather(s.read('parallel_1',category='engineering'),s.read('parallel_2',category='engineering'))
   await s.update('update_v1',1);await s.read('updated',category='validation');await s.probe('updated')
  else:raise ValueError(config['block'])
  await s.close()
  if s.observer.counts['provider.denied']:raise RuntimeError('Forbidden provider path attempted')
  save(out/'RESULT.json',{'execution':'SEALED','at':utc(),'configuration_sha':sha(out/'REQUEST.json'),'health':s.gate.state})
 except BaseException as exc:
  s.hooks.release()
  save(out/'FAILURE.json',{'at':utc(),'type':type(exc).__name__,'error':repr(exc),'traceback':traceback.format_exc()})
  with contextlib.suppress(BaseException):await asyncio.wait_for(s.close(),30)
  raise

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--out',required=True);a=p.parse_args()
 out=Path(a.out).resolve();assert out.is_relative_to(ROOT.resolve())
 out.mkdir(parents=True,exist_ok=False)
 asyncio.run(execute(read(a.config),out))
