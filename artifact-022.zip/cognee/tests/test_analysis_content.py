import unittest,copy,csv,math,asyncio
from src.common import ROOT,PROJECT,read
from src.content import ReceiptIndex
from src.analyze_v2 import unit_metrics,contrast,comparisons,aggregate
from src.worker_v2 import workload
from src.clock import now_ns

class ContentTests(unittest.TestCase):
 def test_incremental_real_staged_binding_and_tamper(self):
  p=ROOT/'runs/e/e002a01';idx=ReceiptIndex(p)
  self.assertFalse(idx.errors)
  for name in ['initial.n1','updated.n1']:
   s=idx.score(read(p/'responses'/f'{name}.json'),name);self.assertTrue(s['coverage_complete']);self.assertEqual(s['compatibility'],'COMPATIBLE_WITHIN_DECLARED_SCOPE')
  payload=read(p/'responses/updated.n1.json');payload[0]['objects_result']['chunks'][0]['payload']['text']='unbound changed content'
  self.assertEqual(idx.score(payload,'updated.n1')['compatibility'],'UNKNOWN')
 def test_old_controlled_real_value_conflict_unchanged(self):
  old=PROJECT/'cognee_coordination_full_v1';cp=read(old/'CHECKPOINT.json')['completed'];p=old/cp['A_73001_AR_NATIVE']['attempt'];idx=ReceiptIndex(p)
  score=idx.score(read(p/'responses/primary.n1.json'),'primary.n1')
  self.assertTrue(score['direct_conflict']);self.assertTrue(score['coverage_complete']);self.assertEqual(score['versions'],[0,1])
 def test_epoch_never_reaches_offline_checker(self):
  text=(ROOT/'src/epoch.py').read_text('utf-8')
  for name in ['ReceiptIndex','score_attempt','usable_by_deadline','coverage_complete','SOURCES']:self.assertNotIn(name,text)

class AnalysisTests(unittest.TestCase):
 def test_bootstrap_known_differences_missing_and_zero_ratio(self):
  a={i:{'value':i+2.} for i in range(10)};b={i:{'value':float(i)} for i in range(10)}
  row=contrast(a,b,['value'],{'kind':'synthetic'},10)[0]
  self.assertEqual(row['mean_difference'],2);self.assertEqual(row['ci_low'],2);self.assertEqual(row['ci_high'],2);self.assertEqual(row['positive_ratio_pairs'],9)
  row=contrast({},b,['value'],{},10)[0];self.assertIsNone(row['mean_difference']);self.assertEqual(row['missing_paired_clusters'],10)
 def test_old_data_count_and_latency_reproduction(self):
  old=PROJECT/'cognee_coordination_full_v1';cp=read(old/'CHECKPOINT.json')['completed'];uid='A_73001_AR_COORDINATED';p=old/cp[uid]['attempt'];cfg=read(p/'REQUEST.json');cfg['requested_mode']='FORCED_FULL'
  rows=[x for x in read(p/'SCORED_READS.json') if x['category']=='primary']
  result=unit_metrics(cfg,rows,read(p/'WRITES.json'),read(p/'CONTENT_SCORES.json'),None,'primary')
  self.assertEqual(result['planned_requests'],1);self.assertEqual(result['usable'],1);self.assertEqual(result['native_calls'],1);self.assertEqual(result['direct_conflicts'],0)
  with (old/'analysis/final/unit_metrics.csv').open(encoding='utf-8-sig',newline='') as f:saved=next(r for r in csv.DictReader(f) if r['unit_id']==uid)
  self.assertAlmostEqual(result['delivered_ms_p95'],float(saved['delivered_ms_p95']),places=8)
 def test_empty_refusal_is_not_classifiable_zero(self):
  cfg={'id':'fake','block':'C','requested_mode':'FORCED_FULL','strategy':'EPOCH_VALIDATED','seed':1,'fault':'INJECT'}
  result=unit_metrics(cfg,[{'service':'UNAVAILABLE_DIRTY','strategy':'EPOCH_VALIDATED','native_calls':[]}],[],{},None,'post_attempt')
  self.assertEqual(result['usable'],0);self.assertIsNone(result['conflict_among_classifiable'])
 def test_six_policy_pairs_and_shared_pure_read_not_duplicated(self):
  rows=[{'unit_id':p,'block':'B','requested_mode':'SHARED_READ_ONLY','stratum':'READ_ONLY','stage':'primary','strategy':p,'seed':1,'usable_fraction':1.} for p in ['NATIVE','DOUBLE_READ','COORDINATED','EPOCH_VALIDATED']]
  result=comparisons(rows);self.assertEqual(len({r['comparison'] for r in result}),6);self.assertTrue(all(r['kind']=='POLICY' for r in result));self.assertEqual(len(aggregate(rows)),4)

class DriverTests(unittest.IsolatedAsyncioTestCase):
 async def test_finite_open_arrivals_rejections_and_no_early_actions(self):
  class Fake:
   def __init__(self):
    self.rows=[];self.reads=[];self.strategy='NATIVE';self.out=ROOT/'runs/test_records/driver_fake';self.out.mkdir(parents=True,exist_ok=True);self.observer=self;self.events=[]
   def emit(self,event,**kw):self.events.append((event,kw))
   async def read(self,name,arrival_ns=None,enqueued_ns=None,**kw):
    if name.startswith('read_'):
     self.rows.append((name,arrival_ns,enqueued_ns,now_ns()));await asyncio.sleep(.01)
   async def probe(self,name):pass
  s=Fake();cfg={'parameters':{'duration':.02,'read_deadline':10,'update_deadline':30,'pending_capacity':64,'read_slots':4,'drain_limit':165},'read_offsets_ns':[i*100_000 for i in range(200)],'update_offsets_ns':[]}
  await workload(s,cfg)
  self.assertEqual(len(s.rows)+len(s.reads),200);self.assertTrue(s.reads)
  self.assertTrue(all(e>=t and d>=e for _,t,e,d in s.rows));self.assertTrue(all(r['published_at_ns']>=r['enqueued_ns']>=r['target_ns'] for r in s.reads))
