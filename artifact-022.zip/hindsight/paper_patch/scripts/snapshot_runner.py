"""Owned subprocess units, durable reconciliation, no failed-unit overwrite."""
import argparse,asyncio,hashlib,json,os,site,subprocess,sys,time,traceback
from pathlib import Path
PATCH=Path(__file__).resolve().parents[1];sys.path.insert(0,str(PATCH/'src'));sys.path.insert(0,str(PATCH))
from recovery.state import atomic,append,read,seal,verify_seal,utc,lease,digest

NATIVE_FILES=[PATCH/'snapshot_fix/repair.py',PATCH/'snapshot_fix/workload.py',Path(__file__).resolve()]
NATIVE_FILES+=list((PATCH/'src').rglob('*.py'))
def code_sha():return hashlib.sha256(json.dumps({str(p.relative_to(PATCH)):digest(p) for p in sorted(NATIVE_FILES)},sort_keys=True).encode()).hexdigest()

def run(cfg):
    rid=f"{cfg['stage']}_{cfg['family']}_{cfg['variant']}_{cfg['seed']}"
    out=PATCH/'snapshot_fix/raw'/rid
    with lease(PATCH/'coordinator.lock'):
        manifest=read(PATCH/'RUN_MANIFEST.json')
        if rid in manifest['runs']:
            previous=manifest['runs'][rid]
            if previous['state']=='ANALYZED':verify_seal(out);return read(out/'experiment_result.json')
            raise RuntimeError('Existing nonfinal unit requires reconciliation: '+rid)
        out.mkdir();atomic(out/'CONFIG.json',cfg);hash_before=code_sha()
        manifest['runs'][rid]=dict(state='RUNNING',config=cfg,code_sha256=hash_before,started_at=utc());atomic(PATCH/'RUN_MANIFEST.json',manifest)
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
        cmd=[sys._base_executable,'-B',str(Path(__file__).resolve()),'worker','--out',str(out)]
        with (out/'console.log').open('x',encoding='utf-8') as log:
            child=subprocess.Popen(cmd,cwd=PATCH,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
            atomic(out/'PROCESS.json',dict(pid=child.pid,started_at=utc(),command=cmd))
            try:rc=child.wait(timeout=cfg.get('timeout_seconds',240))
            except subprocess.TimeoutExpired:child.terminate();child.wait(timeout=20);rc=-99
        if rc or hash_before!=code_sha():
            manifest['runs'][rid].update(state='UNKNOWN' if rc==-99 else 'FAILED',returncode=rc);atomic(PATCH/'RUN_MANIFEST.json',manifest)
            raise RuntimeError('Native unit failed, preserved: '+rid)
        sealed=verify_seal(out)
        from multisource.oracle import check
        errors=[]
        for p in (out/'native').glob('*.sidecar.json'):
            v=read(p)
            if check(v['history'],v['recall'])!=v['verdict']:errors.append(p.name)
        validation=dict(passed=not errors,errors=errors,checked_at=utc());atomic(out/'validation.json',validation)
        manifest['runs'][rid].update(state='ANALYZED' if not errors else 'FAILED',returncode=rc,raw_seal_sha256=digest(out/'RAW_COMPLETE.json'),validation=validation);atomic(PATCH/'RUN_MANIFEST.json',manifest)
        if errors:raise RuntimeError('Frozen checker replay mismatch')
        cp=read(PATCH/'CHECKPOINT.json');cp.update(last_validated_unit=rid,last_unit_seal_sha256=digest(out/'RAW_COMPLETE.json'),updated_at=utc());atomic(PATCH/'CHECKPOINT.json',cp)
        print(json.dumps(dict(unit=rid,status=sealed['result']['classifications'],validated=True)),flush=True)
        return sealed['result']

def configs(stage):
    values=[]
    if stage=='DEV':
        for variant in ['baseline','snapshot']:values.append(dict(system='hindsight',stage=stage,family='WITNESS',variant=variant,seed=4991,template='UPDATE',timeout_seconds=180))
    else:
        old=read(PATCH.parent/'phase3/RUN_MANIFEST.json')['runs']
        known=sorted([v['config'] for v in old.values() if v['config']['stage']=='CONFIRM' and v['config']['workload']=='MATCHED' and v['config']['system']=='hindsight' and v['config']['mitigation']=='M0'],key=lambda x:x['seed'])
        for cfg in known:
            for variant in ['baseline','snapshot']:values.append(dict(system='hindsight',stage='CONFIRM',family='WITNESS',variant=variant,seed=cfg['seed'],template=cfg['template'],timeout_seconds=180,known_phase3_history=True))
        for seed in range(5001,5021):
            for variant in (['baseline','snapshot'] if seed%2 else ['snapshot','baseline']):values.append(dict(system='hindsight',stage='CONFIRM',family='NATURAL',variant=variant,seed=seed,min_writes=15,min_recalls=60,min_duration_seconds=15,max_duration_seconds=90,writer_interval_ms=150,reader_interval_ms=50,timeout_seconds=180))
        for seed in range(6001,6006):
            for variant in (['baseline','snapshot'] if seed%2 else ['snapshot','baseline']):values.append(dict(system='hindsight',stage='CONFIRM',family='READ_HEAVY',variant=variant,seed=seed,warmup_recalls=5,measured_recalls=100,timeout_seconds=240))
    return values

def main():
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['worker','dev','freeze','confirm']);parser.add_argument('--out');args=parser.parse_args()
    if args.action=='worker':
        site.addsitedir(str(PATCH.parent/'.venv/Lib/site-packages'))
        from snapshot_fix.workload import execute
        out=Path(args.out)
        try:asyncio.run(execute(out,read(out/'CONFIG.json')))
        except BaseException as exc:atomic(out/'failure.json',dict(error=repr(exc),traceback=traceback.format_exc(),at=utc()));raise
    elif args.action=='dev':
        for cfg in configs('DEV'):run(cfg)
    elif args.action=='freeze':
        p=PATCH/'configs/SNAPSHOT_CONFIRM.json'
        if p.exists():raise RuntimeError('Existing protocol must not be replaced')
        dev=read(PATCH/'RUN_MANIFEST.json')['runs']
        if len(dev)!=2 or any(v['state']!='ANALYZED' for v in dev.values()):raise RuntimeError('DEV validation incomplete')
        atomic(p,dict(frozen_at=utc(),code_sha256=code_sha(),units=configs('CONFIRM'),statistical_unit='whole workload run',
                      natural_pairs=20,read_heavy_pairs=5,known_witness_pairs=10,bootstrap_draws=10000,bootstrap_seed=102026,
                      acceptable_overhead_rule='Measured RR/shared-snapshot total request p95 ratio <=1.25 and throughput ratio >=0.80 in median of no-write paired repetitions; all errors/coverage changes reported. This is a local engineering threshold, not a deployment guarantee.'))
        print('70 confirm units frozen before execution')
    else:
        protocol=read(PATCH/'configs/SNAPSHOT_CONFIRM.json')
        if protocol['code_sha256']!=code_sha():raise RuntimeError('Frozen native patch code changed')
        for cfg in protocol['units']:run(cfg)
if __name__=='__main__':main()
