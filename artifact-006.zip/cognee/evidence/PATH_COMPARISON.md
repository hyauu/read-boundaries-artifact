# Actual default and forced update paths

The entire 600-unit matrix and frozen analysis completed successfully. All units are accepted; none is not applicable or superseded. The following path totals retain all 1,040 formal update operations, including forty intentionally failed mutations. Selected-trace reading is separately recorded in `PRIMARY_REVIEW_LEDGER.json`; its remaining work does not change these full-data mechanical counts.

## Entry and observed execution

The pinned Cognee 1.6.2 Python update API defaults `chunk_level_diff` to True. DEFAULT_REQUEST omits that argument in the actual call; FORCED_FULL passes False. The separately inspected HTTP default is not an experimentally exercised endpoint. The actual-import pin/source checks remain recorded in `UPDATE_PATH_AUDIT.md`, `SOURCE_MAP.md` and the source audit.

| Block | Request | Operations | Successful return and actual branch | Failure |
|---|---|---:|---|---:|
| A | Default | 160 | 160 incremental | 0 |
| A | Forced full | 160 | 160 full_rebuild, reason disabled | 0 |
| B | Default | 280 | 280 incremental | 0 |
| B | Forced full | 280 | 280 full_rebuild, reason disabled | 0 |
| C | Forced full | 160 | 120 full_rebuild, reason disabled | 40 injected after acknowledged mutation |

All 440 default updates actually enter the incremental branch, return incremental successfully, and have no fallback. Every one reports one region, one added chunk, one deleted chunk, zero reused/kept/reindexed chunks, and one resulting chunk. The fixture therefore exercises the real incremental route but does not measure savings from preserving a large unchanged multi-chunk corpus. All 560 successful forced updates return full_rebuild; `disabled` means the requested False configuration disabled chunk-level diff, not an unexpected eligibility failure.

The adapter consistently recognizes successful incremental returns across all policies. All 1,000 successful updates have their target text observed in the post-update canonical source receipt. No unchanged return or unexpected unchanged/no-op is observed. This is a local observed count, not proof that the pinned API cannot return unchanged for other inputs.

Forty C update calls throw after the first nonempty vector-deletion acknowledgement. Their post-return adapter fields are absent, so the frozen path table contains `None / None` for these calls. `PATH_FIELD_AUDIT.json` separately confirms the original full-rebuild branch-entry and injection receipts for all forty; it does not manufacture an API success status or overwrite those missing frozen fields. The 120 successful C calls comprise forty initial controls and eighty designated rebuilds.

## What the paths change in this matrix

The update route changes the observed service/content failure, rather than eliminating the boundary problem. In A read-before-writer schedules, Native produces direct conflict in 20/20 histories under each request mode. Fixed double read has partial second returns under forced full, but direct-conflict second returns in 20/20 default histories. In writer-before-read schedules, Native and double read are partial under forced full and usable in all twenty histories under default. Coordination and epoch return usable complete bundles in every A primary read. These are forced interleavings, not estimated natural frequencies.

In B, default Native returns 199 direct-conflict observations among 12,010 planned spaced requests and 284 among 12,010 burst requests. Fixed double read also delivers conflicts: 126 spaced and 166 burst. There are no delivered partial-role observations in these default B groups. Forced-full B has no delivered direct conflict, while Native has 144/191 partial returns and 181/278 caller errors in spaced/burst conditions; double read has 116/170 partial returns and 410/536 caller errors. UNKNOWN is a subset of delivered partial returns in these data, not an additional disjoint failure count.

Coordination and epoch each deliver 12,010/12,010 usable requests in both default B conditions. Under forced-full burst, coordination delivers 11,946 usable requests and rejects 64; epoch delivers all 12,010. The usable-fraction paired difference for that epoch-versus-coordination contrast is +0.534 percentage points, descriptive 95% CI [0, 1.601]; it does not establish a strictly positive effect. The shared read-only group returns all 12,010 usable requests for Native, coordination and epoch; double read rejects 2,929 requests, retaining its extra-call cost and original offered workload.

The matched default-minus-forced Native contrasts show +1.657 percentage points of planned-request direct conflict in spaced load, 95% CI [1.575, 1.748], and +2.365 points in burst load, CI [2.224, 2.557]. Default removes the observed forced-path partial-return class but replaces part of that loss with direct conflicts. Native usable-fraction changes are +0.616 points in spaced load, CI [-0.350, 1.133], and +1.540 points in burst load, CI [1.291, 1.780]. These are ten-seed paired cluster comparisons from the frozen 10,000-draw analysis, not request-level independent trials, global multiplicity-adjusted tests, or a cross-system performance ranking.

## Boundary of the conclusion

Actual incremental execution is observed without fallback in this fixed Python entry, one-owner storage configuration and deterministic fixture. Default-path results must not be replaced by an assertion that incremental always solves hybrid visibility. Conversely, forced-full absence of delivered direct conflict in B must not be presented as complete service: missing roles and errors are separate adverse outcomes. The new default B conflicts differ from the prior round's full-rebuild-only ordinary-load observation. No earlier result is overwritten, and no new downstream model experiment is inferred.


A fully read expanded representative is `EXPANDED_BACKEND_CASE_DEFAULT_BURST_74001_NATIVE.json`:16 complete physical-line-hashed backend/path receipts bind the old chunk, newly staged file, inserted chunk/summary/source_ref, first graph-mutation acknowledgement and later same-Data canonical publication. The new incremental objects have null source_content_hash; actual content hashes, document identity, source_ref and acknowledged parent bindings remain necessary. Detailed actual-reading notes and the exact inspected scope are in REVIEW_NOTES.md.
