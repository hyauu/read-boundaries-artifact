# Corrected arrival and resource timing

The fixed 600-unit execution is complete. The following checks use all recorded integer fields and event receipts. They are mechanical checks, distinct from the pending selected public-trace reading and final comparative statistical interpretation.

## Recorded fields

`TIMING_FIELD_AUDIT.json` and its per-unit CSV check 244,440 logical records across all categories and 1,040 update records. There were zero failed checks. Every read has integer target, actual enqueue, publication and deadline fields. Actual enqueue is never earlier than its target, and publication is never earlier than enqueue. No negative duration was clamped or relabeled. All records labeled RETURNED were published by their original deadline.

For all 200 B runs, the audit verifies exact planned read identities and counts, original relative target lists, target-based deadlines, and update targets against each saved window. Pure-read B0 is shared, rather than replicated for each update mode. All 80 C units retain probes targeted at 0, 1, 2, 4 and 8 seconds after the first update's actual termination; the designated recovery target is exactly 15 seconds after that termination. Actual submission is not early. The five subsequent recovery probes are sequential, separately categorized observations.

Across B, 225,594 primary requests entered the pending queue and 14,606 were immediately rejected, totaling 240,200 planned primary requests. Queue rejection remains a service outcome with its own duration and denominator; it is excluded from delivered-response tail latency. There is no READ_DEADLINE outcome or drain-cap marker in this execution. These are observed counts in this fixed local workload, not guarantees for higher load.

## Event ordering

`EVENT_BOUNDARY_AUDIT.json` streams all 8,482,302 original event lines from the 600 sealed attempts and mechanically checks relevant event families against their recorded rows. All 225,594 active-slot acquisitions have matching releases, never exceed four concurrent slots, and release after native termination and body completion. Pending depth stays within 64. Recorded active-slot snapshots agree with the independently reconstructed event sequence. All slots are released by each stream's end.

For coordination, 60,996 acquired read gates are released after native termination. The 260 write gates exclude acquired read gates and cover the native update API call. All gate acquisitions and releases balance. For epoch validation, all 61,482 post-read validations follow native completion and full materialization. These checks concern actual instrumented event order, not a deduction from marginal latency percentiles.

There are 640 emitted stability-wait intervals that later reach a recorded stable read, including 560 wait events while a B active slot is occupied. Their first-wait-event to stable-event durations total 264.768 seconds over all categories. This is a separate event-derived quantity, not a replacement for the frozen per-attempt wait metric. No emitted stability wait remains unmatched at stream end.

## Interpretation and remaining checks

The frozen `epoch_wait_ns` field sums only waits attached to actual native attempts. Fifty DIRTY refusals under epoch have no native attempt and lack an exceptional-path validation-end field. Their zero attached-attempt wait does not certify zero logical waiting. Missing endpoint pairs remain missing. The audited run contains no native result terminating after logical publication, so it does not empirically exercise late-result resource retention; that behavior also has finite engineering tests.

This audit does not prove arbitrary backend-handle safety, multi-owner exclusion, crash safety or absence of uninstrumented writes. Selected full public observations and expanded source/backend receipts still require actual reading. An actual selected full-burst coordination timeline (seed74003) has been inspected and retained in TIMELINE_CASE_FULL_BURST_74003.json:64 rejections split32 before the first write target21s and32 after. The first rejection at13.809s has4 admitted native readers and64 pending, so that early loss cannot be attributed to a writer gate. Read00376 targets18.885s, dispatches23.174s, acquires its gate23.745s after writer4 releases, and finishes native23.898s. Its approximately4.289s queue and0.571s gate intervals are separate same-request measurements; the earlier host slowdown has no established cause. Delivered latency, write latency and queue lateness distributions come from the frozen full-data analysis; marginal p95 values must not be subtracted to invent a causal decomposition.

Both audit helpers were added after the experimental freeze, read existing files only, and did not change execution, scoring, selection or statistical code. Their exact hashes and per-check counts are retained in the JSON reports.


## Controlled-call guard versus workload deadlines

The frozen worker_v2 controlled schedules explicitly call A primary read and update with deadline=90s (worker_v2.py lines12/13 and32/33). All320 primary A read records and320 A updates retain that original90s guard. B open-arrival, C probes, validation and warmup reads use10s; B/C updates use30s. The nominal parameter table is therefore not a universal deadline statement for the injected-hold block. This implementation detail was frozen before formal execution and is now explicitly stated in the manuscript; no raw deadline, score, sample or protocol file was rewritten.

The longest observed A primary read is1168.8019ms and longest A update1210.8744ms, both in A_FORCED_FULL_73020_AW_COORDINATED. No A primary read exceeds10s and no A update exceeds30s. Thus the90s guards did not rescue a measured A outcome beyond the nominal workload budgets in this execution, but controlled latency is still not a natural workload estimate.
