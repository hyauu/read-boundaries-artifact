"""Read-only reconstruction checks using only full exported CSV tables.

No native dependency, database, network, model, rescore or new experiment.
This is an artifact consistency check, not public-trace reading. Optional paired
reconstruction calls the frozen offline statistical function, not its raw runner.
"""
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import sys


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        yield from csv.DictReader(stream)


def truth(value):
    assert value in ("True", "False", ""), value
    return value == "True"


def percentile(values, q):
    if not values:
        return None
    values = sorted(values)
    position = (len(values) - 1) * q
    lo, hi = math.floor(position), math.ceil(position)
    return values[lo] + (values[hi] - values[lo]) * (position - lo)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--output", type=Path)
    ap.add_argument("--recompute-pairs", action="store_true")
    args = ap.parse_args()
    root = args.root.resolve()
    tables = root / "analysis/final"
    counts, delivered_ms, all_calls = defaultdict(Counter), defaultdict(list), Counter()
    logical_ids = defaultdict(set)
    logical_total = 0
    for r in rows(tables / "read_requests.csv"):
        uid, category = r["unit_id"], r["category"]
        key = (uid, category)
        assert r["id"] not in logical_ids[uid], (uid, r["id"])
        logical_ids[uid].add(r["id"])
        logical_total += 1
        c = counts[key]
        c["planned_requests"] += 1
        c[r["service"].lower()] += 1
        c["usable"] += truth(r["usable_by_deadline"])
        target = int(r["target_ns"])
        assert int(r["enqueued_ns"]) >= target
        assert int(r["published_at_ns"]) >= target
        c["late_enqueues"] += int(r["enqueued_ns"]) > target
        # The frozen controlled worker uses a 90 s guard around held A calls.
        # B, C and validation/warmup records use the nominal 10 s read budget.
        budget = 90 if r["block"] == "A" and category == "primary" else 10
        assert int(r["deadline_ns"]) == target + budget * 1_000_000_000
        c["discarded_attempts"] += int(r["epoch_discarded"])
        c["native_calls"] += int(r["native_call_count"])
        all_calls[key] += int(r["native_call_count"])
        if r["service"] == "RETURNED":
            c["delivered"] += 1
            c["unknown"] += r["compatibility"] == "UNKNOWN"
            c["classifiable"] += r["compatibility"] != "UNKNOWN"
            c["partial"] += not truth(r["coverage_complete"])
            c["direct_conflicts"] += truth(r["direct_conflict"])
            for role, present in json.loads(r["roles"]).items():
                assert isinstance(present, bool)
                c["role_" + role] += present
            c["freshness_unknown"] += r["lag_at_return"] == ""
            for endpoint in ("start", "return"):
                lag = r["lag_at_" + endpoint]
                if lag != "":
                    c["freshness_known_" + endpoint] += 1
                    c["stale_" + endpoint] += float(lag) > 0
                    c["ahead_success_head_" + endpoint] += float(lag) < 0
            delivered_ms[key].append((int(r["published_at_ns"]) - target) / 1e6)
    attempt_counts, attempt_total = defaultdict(Counter), 0
    for r in rows(tables / "native_attempts.csv"):
        key = (r["unit_id"], r["category"])
        c = attempt_counts[key]
        attempt_total += 1
        c["native_calls"] += 1
        discarded = r["validation"] == "DISCARDED"
        score = (json.loads(r["score"]) if r["score"] else {}) or {}
        c["discarded_attempts"] += discarded
        c["internal_conflicts_discarded"] += discarded and bool(score.get("direct_conflict"))
        c["internal_errors_discarded"] += discarded and r["status"] == "NATIVE_ERROR"
        c["stable_native_errors"] += r["validation"] == "STABLE_NATIVE_ERROR"
        c["response_bytes"] += int(r["response_bytes"] or 0)
    assert {k: v["native_calls"] for k, v in attempt_counts.items()} == {
        k: n for k, n in all_calls.items() if n
    }
    group_counts = defaultdict(Counter)
    unit_rows = list(rows(tables / "unit_metrics.csv"))
    checked_cells = 0
    for u in unit_rows:
        key = (u["unit_id"], u["stage"])
        c = counts[key]
        assert c["planned_requests"] > 0
        for name in ("native_calls", "discarded_attempts"):
            assert c[name] == attempt_counts[key][name], (key, name)
        for name, n in {**c, **attempt_counts[key]}.items():
            if name in u:
                assert int(u[name]) == n, (key, name, u[name], n)
                checked_cells += 1
        for suffix, q in (("p25", .25), ("p50", .5), ("p75", .75), ("p95", .95)):
            actual = percentile(delivered_ms[key], q)
            stored = u["delivered_ms_" + suffix]
            if actual is None:
                assert stored == ""
            else:
                assert math.isclose(actual, float(stored), rel_tol=1e-10, abs_tol=1e-7)
            checked_cells += 1
        g = (u["block"], u["requested_mode"], u["stratum"], u["stage"], u["strategy"])
        for name in ("planned_requests", "delivered", "usable", "unknown", "partial", "direct_conflicts", "native_error", "queue_rejected", "unavailable_dirty", "native_calls", "discarded_attempts"):
            group_counts[g][name] += int(u[name])
    summary = json.loads((tables / "SUMMARY.json").read_text(encoding="utf-8"))
    assert summary["logical_reads_all_categories"] == logical_total == 244440
    assert summary["native_attempts"] == attempt_total == 276776
    assert summary["units_or_stages"] == len(unit_rows) == 680
    assert len(logical_ids) == summary["accounted"] == summary["planned"] == 600
    comparisons = list(rows(tables / "paired_comparisons.csv"))
    assert len(comparisons) == 4700
    assert all(r["draws"] == "10000" and r["bootstrap_seed"] == "2026101702" and r["ci_level"] == "0.95" for r in comparisons)
    reconstructed_pairs = False
    if args.recompute_pairs:
        freeze = json.loads((root / "configs/FREEZE.json").read_text())
        implementation = root / "src/analyze_v2.py"
        assert hashlib.sha256(implementation.read_bytes()).hexdigest() == freeze["analysis_implementation"]["sha256"]
        sys.path.insert(0, str(root))
        from src.analyze_v2 import comparisons as frozen_comparisons
        typed_units = []
        text_fields = {"unit_id", "block", "strategy", "requested_mode", "stratum", "stage"}
        for row in unit_rows:
            typed_units.append({k: (v if k in text_fields else None if v == "" else float(v)) for k, v in row.items()})
        expected = frozen_comparisons(typed_units)
        assert len(expected) == len(comparisons)
        for a, b in zip(expected, comparisons):
            for k, v in a.items():
                if v is None:
                    assert b[k] == ""
                elif isinstance(v, (int, float)) and not isinstance(v, bool):
                    assert math.isclose(float(v), float(b[k]), rel_tol=1e-10, abs_tol=1e-10), (k, v, b[k])
                else:
                    assert str(v) == b[k], (k, v, b[k])
        reconstructed_pairs = True
    output = {
        "kind": "OFFLINE_EXPORTED_TABLE_RECONSTRUCTION",
        "scope": "All logical and native-attempt CSV rows, unit count/coverage/service/role/freshness/discard cells, delivered quantiles and saved paired method parameters. Not raw rescoring, public-trace reading, or an independent/human review.",
        "pass": True, "logical_rows": logical_total, "native_attempts": attempt_total,
        "unit_stages": len(unit_rows), "compared_cells": checked_cells,
        "paired_rows": len(comparisons), "all_saved_pairs_reconstructed": reconstructed_pairs,
        "groups": [dict(zip(("block", "requested_mode", "stratum", "stage", "strategy"), key), **value) for key, value in sorted(group_counts.items())],
    }
    if args.output:
        args.output.resolve().write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in output.items() if k != "groups"}))


if __name__ == "__main__":
    main()
