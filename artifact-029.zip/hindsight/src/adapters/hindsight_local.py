"""Controlled Hindsight integration with real Postgres and native queued workers.

Only model outputs/embeddings are fixtures. Memory writes, worker claiming,
consolidation, curation and recall execute the installed, pinned upstream code.
The fixture is not a production model-quality or latency measurement.
"""
from __future__ import annotations

import asyncio
import contextvars
import copy
import json
import os
from pathlib import Path
from time import perf_counter
from uuid import uuid4

ROOT = Path(__file__).resolve().parents[2]
os.environ["HINDSIGHT_API_LLM_PROVIDER"] = "mock"
os.environ["HINDSIGHT_API_LLM_MODEL"] = "mock-model"
os.environ["HINDSIGHT_API_LLM_API_KEY"] = "unused-offline-fixture"
os.environ["HINDSIGHT_API_RETAIN_LLM_PROVIDER"] = "mock"
os.environ["HINDSIGHT_API_CONSOLIDATION_LLM_PROVIDER"] = "mock"
os.environ["HINDSIGHT_API_REFLECT_LLM_PROVIDER"] = "mock"
os.environ["HINDSIGHT_API_RERANKER_PROVIDER"] = "none"
os.environ["HINDSIGHT_API_EMBEDDINGS_PROVIDER"] = "tei"  # Explicit object below overrides factory.
os.environ["OTEL_SDK_DISABLED"] = "true"

from hindsight_api.engine.cross_encoder import RRFPassthroughCrossEncoder
from hindsight_api.engine.embeddings import Embeddings
from hindsight_api.engine.memories import get_memories
from hindsight_api.engine.memory_engine import MemoryEngine
from hindsight_api.models import RequestContext
from hindsight_api.worker.poller import WorkerPoller
from checker import check

JOB = contextvars.ContextVar("phase0_observed_job", default=None)


class FixtureEmbeddings(Embeddings):
    @property
    def provider_name(self):
        return "phase0_constant_fixture"

    @property
    def dimension(self):
        return 8

    async def initialize(self):
        pass

    async def encode(self, texts):
        # Ensure tiny relevant data are not lost to ANN/model-quality effects.
        return [[1.0] + [0.0] * 7 for _ in texts]


def write_json(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str), encoding="utf-8")


class NativeSession:
    def __init__(self, label):
        self.label = label
        self.bank = f"torn-phase0-{label}-{uuid4().hex[:8]}"
        self.ctx = RequestContext()
        runtime = json.loads((ROOT / "outputs/baseline/database_runtime.json").read_text(encoding="utf-8-sig"))
        self.engine = MemoryEngine(
            db_url=f"postgresql://anonymous:LOCAL_FIXTURE_PASSWORD@127.0.0.1:{runtime['port']}/torn_phase0",
            memory_llm_provider="mock", memory_llm_model="mock-model",
            memory_llm_api_key="unused-offline-fixture", embeddings=FixtureEmbeddings(),
            cross_encoder=RRFPassthroughCrossEncoder(), pool_min_size=2, pool_max_size=8)
        self.events = []
        self.insert_events = []
        self.native_to_revision = {}
        self.revisions = []
        self.commits = []
        self.raw_id = None
        self.store = None
        self.originals = {}
        self.poller = None
        self.read_gate = None
        self.read_gate_hit = None
        self.source_read_mapping = {}
        self.source_gate = None
        self.source_gate_hit = None
        self.source_gate_used = False
        self.job_source_reads = {}
        self.required_fences = []
        self.mapping_uncertain = False

    async def initialize(self):
        await self.engine.initialize()
        self.store = get_memories()
        self.originals["insert_observation"] = self.store.insert_observation
        self.originals["recall_source_facts"] = self.store.recall_source_facts
        self.originals["find_unconsolidated"] = self.store.find_unconsolidated
        # This Phase-0 observer supports insert + invalidate + recreate generations only.
        # Richer native in-place derived mutations must remain unclassified, never guessed.
        for name in ["rewrite_observation", "fold_sources_into_observation", "fold_observation_into_twin", "upsert_observation"]:
            original = getattr(self.store, name)
            self.originals[name] = original

            async def observe_unsupported(*args, _original=original, _name=name, **kwargs):
                result = await _original(*args, **kwargs)
                if kwargs.get("bank_id") == self.bank:
                    self.mapping_uncertain = True
                    self.events.append(dict(event="unsupported_derived_mutation_observed", method=_name))
                return result

            setattr(self.store, name, observe_unsupported)

        async def find_unconsolidated(**kwargs):
            result = await self.originals["find_unconsolidated"](**kwargs)
            if kwargs.get("bank_id") == self.bank and result:
                mapping = {str(m.unit_id): self.native_to_revision.get(str(m.unit_id)) for m in result}
                self.job_source_reads.setdefault(JOB.get(), {}).update(mapping)
                self.events.append(dict(event="native_worker_source_read", native_operation_id=JOB.get(), mapping=mapping))
                if self.source_gate is not None and not self.source_gate_used:
                    self.source_gate_used = True
                    self.source_gate_hit.set()
                    await asyncio.wait_for(self.source_gate.wait(), timeout=30)
            return result

        async def insert_observation(**kwargs):
            result = await self.originals["insert_observation"](**kwargs)
            if kwargs.get("bank_id") == self.bank:
                self.insert_events.append(dict(native_id=str(result), native_operation_id=JOB.get(),
                                               source_ids=[str(s) for s in kwargs["source_memory_ids"]],
                                               source_revisions={str(s): self.job_source_reads.get(JOB.get(), {}).get(str(s))
                                                                 for s in kwargs["source_memory_ids"]}))
            return result

        async def recall_source_facts(**kwargs):
            if kwargs.get("bank_id") == self.bank and self.read_gate is not None:
                self.read_gate_hit.set()
                await asyncio.wait_for(self.read_gate.wait(), timeout=30)
            result = await self.originals["recall_source_facts"](**kwargs)
            if kwargs.get("bank_id") == self.bank:
                self.source_read_mapping = {str(key): self.native_to_revision.get(str(key)) for key in result}
                self.events.append(dict(event="native_source_read_completed", mapping=self.source_read_mapping.copy()))
            return result

        self.store.insert_observation = insert_observation
        self.store.recall_source_facts = recall_source_facts
        self.store.find_unconsolidated = find_unconsolidated

        async def execute(task):
            token = JOB.set(task.get("operation_id"))
            self.events.append(dict(event="native_worker_dispatch", task=copy.deepcopy(task)))
            try:
                await self.engine.execute_task(task)
            finally:
                JOB.reset(token)

        self.poller = WorkerPoller(self.engine._backend, f"phase0-{self.label}", execute,
                                   max_slots=4, slot_reservations={"consolidation": 2})
        await self.poller.recover_own_tasks()

    def publication(self, updates, revisions=()):
        cid = f"{self.label}:commit:{len(self.commits) + 1}"
        parents = [self.commits[-1]["commit_id"]] if self.commits else []
        self.commits.append(dict(commit_id=cid, parents=parents, updates=updates))
        for value in revisions:
            self.revisions.append({**value, "commit_id": cid, "provenance_complete": True})
        return cid

    def mock_fact(self, text):
        self.engine._retain_llm_config.set_mock_response({"facts": [
            dict(what=text, when="N/A", where="N/A", who="Alice", why="N/A",
                 fact_kind="conversation", fact_type="world", entities=[{"text": "Alice"}])]})

    def observe_raw_create(self, ids):
        if self.raw_id is not None:
            raise RuntimeError("Raw create was already observed")
        if len(ids) != 1:
            raise RuntimeError(f"Tiny fixture did not produce exactly one native fact: {ids}")
        self.raw_id = str(ids[0])
        self.native_to_revision[self.raw_id] = "a1"
        self.publication({"A": "a1"}, [dict(logical_id="A", revision_id="a1", kind="raw",
                                              native_id=self.raw_id, parent_revision=None, changed_fields=["text"])])
        self.events.append(dict(event="native_retain_return", native_ids=ids))

    async def create(self, text="Alice lives in Seattle."):
        self.mock_fact(text)
        ids = await self.engine.retain_async(self.bank, text, document_id="alice_location", request_context=self.ctx)
        self.observe_raw_create(ids)

    async def replace(self, text="Alice lives in San Francisco."):
        self.mock_fact(text)
        ids = await self.engine.retain_async(self.bank, text, document_id="alice_location", request_context=self.ctx)
        if len(ids) != 1 or str(ids[0]) == self.raw_id:
            raise RuntimeError("Expected one newly generated raw UUID from native document replacement")
        old_id = self.raw_id
        self.raw_id = str(ids[0])
        self.native_to_revision.pop(old_id, None)
        self.native_to_revision[self.raw_id] = "a2"
        self.publication({"A": "a2", "S": None}, [dict(logical_id="A", revision_id="a2", kind="raw",
                                                        native_id=self.raw_id, parent_revision="a1", changed_fields=["text"])])
        self.events.append(dict(event="native_document_replace_return", old_id=old_id, native_ids=ids))

    async def update(self, text="Alice lives in San Francisco."):
        result = await self.engine.update_memory_unit(self.bank, self.raw_id, text=text, request_context=self.ctx)
        if result is None:
            raise RuntimeError("Native curation failed to find the fact")
        self.native_to_revision[self.raw_id] = "a2"
        self.publication({"A": "a2", "S": None}, [dict(logical_id="A", revision_id="a2", kind="raw",
                                                        native_id=self.raw_id, parent_revision="a1", changed_fields=["text"])])
        self.events.append(dict(event="native_update_return", response=result))

    async def delete(self):
        result = await self.engine.delete_document(document_id="alice_location", bank_id=self.bank,
                                                   request_context=self.ctx)
        if result.get("document_deleted") != 1 or result.get("memory_units_deleted", 0) < 1:
            raise RuntimeError(f"Native delete acknowledgement did not confirm the expected deletion: {result}")
        cid = self.publication({"A": None, "S": None})
        self.required_fences.append(cid)  # Native live recall after completed document deletion.
        self.events.append(dict(event="native_delete_document_return", response=result))
        self.native_to_revision.pop(self.raw_id, None)

    async def drain(self):
        # Exact native worker claim/execute/terminal paths, scheduler-stepped rather than sleep-polled.
        started = perf_counter()
        for _ in range(30):
            tasks = await self.poller.claim_batch()
            for task in tasks:
                await self.poller.execute_task(task)
            if not await self.poller.wait_for_active_tasks(timeout=20):
                raise RuntimeError("Native worker failed to complete within the bounded baseline window")
            operations = await self.engine.list_operations(self.bank, limit=100, request_context=self.ctx)
            self.events.append(dict(event="native_operation_status", response=operations))
            rows = operations.get("operations", operations.get("items", []))
            failed = [r for r in rows if r.get("status") == "failed"]
            if failed:
                raise RuntimeError(f"Native worker failed: {failed}")
            outstanding = [r for r in rows if r.get("status") in ("pending", "processing")]
            if not tasks and not outstanding:
                break
            if perf_counter() - started > 45:
                raise RuntimeError("Native queue did not drain within 45 seconds")
            await asyncio.sleep(0.05)
        else:
            raise RuntimeError("Native queue did not drain")
        self.observe_publications()

    def observe_publications(self, completed_operations=None):
        seen = {r.get("native_id") for r in self.revisions}
        fresh = [event for event in self.insert_events if event["native_id"] not in seen
                 and (completed_operations is None or event["native_operation_id"] in completed_operations)]
        if len(fresh) > 1:
            raise RuntimeError("Unexpected multiple observation publications: mapping is UNKNOWN")
        for event in fresh:
            if len(event["source_ids"]) != 1 or event["source_ids"][0] != self.raw_id:
                raise RuntimeError("Unexpected derived source set: mapping is UNKNOWN")
            parent = event["source_revisions"].get(self.raw_id)
            if parent is None:
                raise RuntimeError("Unobserved derived source revision: mapping is UNKNOWN")
            rid = f"s:{event['native_id']}"
            self.native_to_revision[event["native_id"]] = rid
            self.publication({"S": rid}, [dict(logical_id="S", revision_id=rid, kind="derived",
                                               native_id=event["native_id"], generation=event["native_id"],
                                               parent_revision=None, changed_fields=["text", "sources"],
                                               derived_from=[dict(logical_id="A", revision_id=parent)],
                                               observed_native_publication=event)])

    def history(self):
        return dict(complete=True, revisions=copy.deepcopy(self.revisions), commits=copy.deepcopy(self.commits),
                    frontier=[c["commit_id"] for c in self.commits], operations=copy.deepcopy(self.events))

    async def recall(self, output_dir, name, required=("A", "S")):
        # Controlled experiment ensures no writes run during retrieval except after source-read gate.
        main_mapping = self.native_to_revision.copy()
        self.source_read_mapping = {}
        t0 = perf_counter()
        result = await self.engine.recall_async(
            self.bank, "Alice location", fact_type=["world", "observation"], include_source_facts=True,
            include_entities=False, include_chunks=False, max_tokens=4096, reranking="rrf", request_context=self.ctx)
        native_latency_ms = (perf_counter() - t0) * 1000
        raw = result.model_dump(mode="json")
        write_json(output_dir / f"{name}.native.json", raw)
        items = []
        complete = not self.mapping_uncertain
        by_rev = {r["revision_id"]: r for r in self.revisions}
        for location, facts, mapping in [
            ("results", raw["results"], main_mapping),
            ("source_facts", list((raw.get("source_facts") or {}).values()), self.source_read_mapping)]:
            for fact in facts:
                rid = mapping.get(fact["id"])
                if rid not in by_rev:
                    complete = False
                    continue
                revision = by_rev[rid]
                value = dict(logical_id=revision["logical_id"], revision_id=rid, role="current",
                             native_id=fact["id"], native_location=location)
                if revision["kind"] == "derived":
                    value["generation"] = revision["generation"]
                items.append(value)
        annotated = dict(native_boundary="MemoryEngine.recall_async(types=world,observation;include_source_facts=True)",
                         mapping_complete=complete, items=items, required_coverage=list(required),
                         required_fences=self.required_fences.copy())
        history = self.history()
        verdict = check(history, annotated)
        evidence = dict(system="Hindsight", commit="9269b88417ed263e5a8350f2e416ca2b322756b1",
                        evidence_type="native_pipeline_with_offline_model_fixtures", is_native_experiment=True,
                        bank_id=self.bank, native_output=f"{name}.native.json", history=history, recall=annotated,
                        verdict=verdict, read_latency_ms=native_latency_ms,
                        total_read_with_observer_ms=(perf_counter() - t0) * 1000,
                        limitations=["Official mock LLM outputs", "Constant embedding fixture", "RRF reranking",
                                     "Scheduler steps actual native worker claim/execute; no autonomous polling loop",
                                     "Observer is valid only for this controlled tiny single-writer history"])
        write_json(output_dir / f"{name}.sidecar.json", evidence)
        return evidence

    async def close(self):
        if self.read_gate is not None:
            self.read_gate.set()
        if self.source_gate is not None:
            self.source_gate.set()
        if self.poller is not None:
            await self.poller.shutdown_graceful(timeout=5)
        if self.store is not None:
            for name, value in self.originals.items():
                setattr(self.store, name, value)
        await self.engine.close()
