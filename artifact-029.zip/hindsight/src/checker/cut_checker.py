"""Small-history dependency-cut oracle. No text interpretation or clock ordering.

This consumes trusted event provenance, not arbitrary unannotated native text.
Missing or invalid provenance returns UNKNOWN. Limit: 16 committed events.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


class IncompleteModel(ValueError):
    pass


@dataclass
class Verdict:
    status: str
    reason: str
    matching_cut: list[str] | None = None
    missing_coverage: list[str] | None = None
    compatible_at_frontier: bool | None = None
    legal_cuts_examined: int = 0


def _require(value: bool, reason: str) -> None:
    if not value:
        raise IncompleteModel(reason)


class History:
    def __init__(self, history: dict[str, Any]):
        _require(history.get("complete") is True, "Commit history completeness is not established")
        self.revisions: dict[str, dict] = {}
        self.commits: dict[str, dict] = {}
        self.ancestors: dict[str, set[str]] = {}
        for revision in history["revisions"]:
            rid = revision["revision_id"]
            _require(rid not in self.revisions, "Duplicate immutable revision ID")
            _require(revision["kind"] in ("raw", "derived"), "Unknown revision kind")
            _require(bool(revision["logical_id"]), "Missing logical ID")
            self.revisions[rid] = revision
        for commit in history["commits"]:
            cid = commit["commit_id"]
            _require(cid not in self.commits, "Duplicate commit ID")
            parents = set(commit["parents"])
            _require(parents <= self.commits.keys(), "Commits must be in causal topological order")
            closure = set(parents)
            for parent in parents:
                closure.update(self.ancestors[parent])
            self.ancestors[cid] = closure
            for logical_id, rid in commit["updates"].items():
                if rid is not None:
                    _require(rid in self.revisions, "Committed update has no revision record")
                    revision = self.revisions[rid]
                    _require(revision["logical_id"] == logical_id, "Commit logical ID mismatch")
                    _require(revision["commit_id"] == cid, "Revision publication commit mismatch")
                # Two writes of one logical object must have an observed order.
                for previous_id, previous in self.commits.items():
                    if logical_id in previous["updates"]:
                        _require(previous_id in closure, "Unordered writes to one logical object")
            self.commits[cid] = commit
        _require(len(self.commits) <= 16, "Small-history oracle limit exceeded (16 commits)")
        for rid, revision in self.revisions.items():
            cid = revision["commit_id"]
            _require(cid in self.commits, "Revision is not linked to an observed commit")
            _require(self.commits[cid]["updates"].get(revision["logical_id"]) == rid,
                     "Revision was not published by its commit")
            parent = revision.get("parent_revision")
            if parent is not None:
                _require(parent in self.revisions, "Missing parent revision")
                previous = self.revisions[parent]
                _require(previous["logical_id"] == revision["logical_id"], "Parent belongs to another object")
                _require(previous["commit_id"] in self.ancestors[cid], "Parent revision lacks causal predecessor")
        self.frontier = set(history["frontier"])
        _require(self.frontier <= self.commits.keys(), "Frontier includes unknown/uncommitted events")
        for cid in self.frontier:
            _require(self.ancestors[cid] <= self.frontier, "Frontier is not causally closed")
        self.fences = set(history.get("required_fences", []))
        _require(self.fences <= self.frontier, "Required lifecycle fence is outside frontier")
        self.constraints: dict[str, str] = {}
        self.publications: set[str] = set()
        self.conflicting_constraints = False

    def revision_closure(self, rid: str, stack: set[str] | None = None) -> list[dict]:
        _require(rid in self.revisions, "Native item/parent has no immutable sidecar revision")
        stack = set() if stack is None else stack
        _require(rid not in stack, "Cyclic derived provenance")
        revision = self.revisions[rid]
        _require(revision["commit_id"] in self.frontier, "Returned revision publication is outside observed frontier")
        _require(revision.get("provenance_complete") is True, "Parent provenance is incomplete")
        refs = [revision]
        if revision["kind"] == "derived":
            _require(revision.get("generation") is not None, "Derived generation is missing")
            _require("derived_from" in revision, "Derived parent list is missing")
            _require(bool(revision["derived_from"]), "Empty derived parent set has no established basis")
            for dep in revision["derived_from"]:
                dep_id = dep["revision_id"]
                closure = self.revision_closure(dep_id, stack | {rid})
                _require(closure[0]["logical_id"] == dep["logical_id"], "Dependency logical ID mismatch")
                _require(closure[0]["commit_id"] in self.ancestors[revision["commit_id"]],
                         "Dependency was not committed before derivation publication")
                refs.extend(closure)
        return refs

    def add_constraints(self, refs: list[dict]) -> None:
        for revision in refs:
            key, rid = revision["logical_id"], revision["revision_id"]
            if key in self.constraints and self.constraints[key] != rid:
                self.conflicting_constraints = True
            self.constraints[key] = rid
            self.publications.add(revision["commit_id"])

    def cuts(self):
        """Enumerate closed committed cuts; independent objects may advance concurrently."""
        ordered = [c for cid, c in self.commits.items() if cid in self.frontier]

        def visit(index: int, included: set[str], state: dict[str, str | None]):
            if index == len(ordered):
                if self.fences <= included:
                    yield included, state
                return
            commit = ordered[index]
            yield from visit(index + 1, included, state)
            if set(commit["parents"]) <= included:
                yield from visit(index + 1, included | {commit["commit_id"]},
                                 {**state, **commit["updates"]})

        yield from visit(0, set(), {})

    @staticmethod
    def explains(refs: list[dict], cut: set[str], state: dict) -> bool:
        return all(r["commit_id"] in cut and state.get(r["logical_id"]) == r["revision_id"] for r in refs)


def check(history: dict[str, Any], recall: dict[str, Any]) -> dict[str, Any]:
    try:
        _require(recall.get("mapping_complete") is True, "Native-result provenance mapping is incomplete")
        _require(bool(recall.get("native_boundary")), "No native recall boundary recorded")
        model = History(history)
        all_cuts = list(model.cuts())
        returned: set[str] = set()
        for item in recall["items"]:
            rid = item["revision_id"]
            refs = model.revision_closure(rid)
            revision = refs[0]
            _require(item["logical_id"] == revision["logical_id"], "Native item logical ID mismatch")
            if revision["kind"] == "derived":
                _require(item.get("generation") == revision["generation"], "Native item generation missing/mismatch")
            role = item["role"]
            _require(role in ("current", "historical"), "Native authority role is not established")
            returned.add(item["logical_id"])
            if role == "current":
                model.add_constraints(refs)
            else:
                # Historical evidence has its own historical basis and does not pin today's state.
                historical_cuts = History({**history, "required_fences": []}).cuts()
                _require(any(model.explains(refs, cut, state) for cut, state in historical_cuts),
                         "Historical citation has no established committed dependency basis")
        missing = sorted(set(recall.get("required_coverage", [])) - returned)
        matched: list[set[str]] = []
        if not model.conflicting_constraints:
            for cut, state in all_cuts:
                if model.publications <= cut and all(state.get(k) == r for k, r in model.constraints.items()):
                    matched.append(cut)
        if not matched:
            return asdict(Verdict("TORN", "No legal committed dependency cut explains the current bundle",
                                  missing_coverage=missing, compatible_at_frontier=False,
                                  legal_cuts_examined=len(all_cuts)))
        fresh = any(cut == model.frontier for cut in matched)
        witness = next((cut for cut in matched if cut == model.frontier), max(matched, key=len))
        status = "COVERAGE_MISS" if missing else ("PASS" if fresh else "STALE")
        reason = ("Compatible bundle misses declared coverage targets" if missing else
                  "Bundle is compatible with the observed committed frontier" if fresh else
                  "Bundle is compatible with an older committed cut")
        return asdict(Verdict(status, reason, sorted(witness), missing, fresh, len(all_cuts)))
    except (IncompleteModel, KeyError, TypeError, ValueError) as exc:
        return asdict(Verdict("UNKNOWN", str(exc)))
