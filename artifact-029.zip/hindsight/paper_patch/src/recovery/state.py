"""Durable state, evidence integrity, and a Windows single-coordinator lease."""
from __future__ import annotations
import hashlib
import json
import os
import shutil
from pathlib import Path
from datetime import datetime, timezone
from contextlib import contextmanager

ROOT = Path(__file__).resolve().parents[2]
CHECKER = ROOT.parent/'src/checker/cut_checker.py'

def utc():
    return datetime.now(timezone.utc).isoformat()

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def atomic(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name+f'.tmp.{os.getpid()}')
    with temp.open('w', encoding='utf-8', newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2,default=str)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp,path)

def append(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,default=str)+'\n')
        stream.flush()
        os.fsync(stream.fileno())

@contextmanager
def lease(path):
    import msvcrt
    path = Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a+b') as stream:
        if stream.tell()==0:
            stream.write(b'0')
            stream.flush()
        stream.seek(0)
        try:
            msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
        except OSError as exc:
            raise RuntimeError('Another coordinator/worker owns the lease; do not reconcile a live run') from exc
        try:
            yield
        finally:
            stream.seek(0)
            msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)

def code_hash(root=ROOT):
    paths = sorted(p for base in [root/'src',root/'scripts',root/'tests'] for p in base.rglob('*.py'))
    paths += [root/'run_phase1.py'] if (root/'run_phase1.py').exists() else []
    values={str(p.relative_to(root)):digest(p) for p in paths}
    return hashlib.sha256(json.dumps(values,sort_keys=True).encode()).hexdigest()

def identity(config, root=ROOT):
    hashes={'config_hash':hashlib.sha256(json.dumps(config,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
            'code_hash':code_hash(root),'checker_hash':digest(CHECKER)}
    tag=hashlib.sha256(json.dumps(hashes,sort_keys=True).encode()).hexdigest()[:12]
    return f"{config['system']}_{config['workload']}_{config['operation_family']}_{config['mitigation']}_seed{config['seed']:02d}_{tag}",hashes

def archive_code(root,expected_hash):
    """Keep exact harness source bytes for each newly executed code version."""
    if code_hash(root)!=expected_hash:raise RuntimeError('Harness changed before source archive')
    dest=root/'analysis/code_snapshots'/expected_hash
    paths=sorted(p for base in [root/'src',root/'scripts',root/'tests'] for p in base.rglob('*.py'))+[root/'run_phase1.py']
    for p in paths:
        q=dest/p.relative_to(root);q.parent.mkdir(parents=True,exist_ok=True)
        if q.exists():
            if digest(q)!=digest(p):raise RuntimeError('Archived source does not match current source')
        else:shutil.copyfile(p,q)
    if code_hash(root)!=expected_hash:raise RuntimeError('Harness changed during source archive')
    atomic(dest/'SOURCE_MANIFEST.json',{'code_hash':expected_hash,'files':{p.relative_to(root).as_posix():digest(p) for p in paths}})
    return dest

def update_status(root=ROOT, **updates):
    status=read(root/'STATUS.json')
    status.update(updates,updated_at=utc())
    atomic(root/'STATUS.json',status)

def set_run(root,run_id,**updates):
    manifest=read(root/'RUN_MANIFEST.json')
    manifest['runs'][run_id].update(updates,updated_at=utc())
    manifest['updated_at']=utc()
    atomic(root/'RUN_MANIFEST.json',manifest)

def seal(out, files, scientific, result):
    """Only sealed raw evidence is eligible for validation/checkpoint."""
    paths={Path(p).relative_to(out).as_posix():digest(p) for p in files}
    atomic(out/'RAW_COMPLETE.json',{'files':paths,'scientific':scientific,'result':result,'sealed_at':utc()})

def verify_seal(out):
    value=read(out/'RAW_COMPLETE.json')
    for name,expected in value['files'].items():
        path=(out/name).resolve()
        if not path.is_relative_to(out.resolve()) or not path.is_file() or digest(path)!=expected:
            raise RuntimeError(f'Raw evidence absent or changed: {name}')
    return value

def checkpoint(root,run_id,validation):
    entry=read(root/'RUN_MANIFEST.json')['runs'][run_id]
    out=root/'runs'/run_id
    sealed=verify_seal(out)
    if not validation.get('passed'):
        raise RuntimeError('Cannot checkpoint unvalidated evidence')
    atomic(root/'CHECKPOINT.json',dict(last_completed_run_id=run_id,
        **{key:entry['config'][key] for key in ['system','workload','operation_family','mitigation','seed']},
        **entry['hashes'],raw_output_paths=[str((out/name).relative_to(root)) for name in sealed['files']],
        raw_seal_hash=digest(out/'RAW_COMPLETE.json'),validation_result=validation,
        analysis_status='ANALYZED',next_run=None,updated_at=utc()))
    update_status(root,last_validated_run_id=run_id)

def startup(root=ROOT, verify_frozen=False):
    """Read the on-disk recovery contract before choosing any next action."""
    plan=(root/'PHASE3_PLAN.md').read_text(encoding='utf-8')
    status=read(root/'STATUS.json'); point=read(root/'CHECKPOINT.json'); manifest=read(root/'RUN_MANIFEST.json')
    if root==ROOT and digest(root/'PHASE3_PLAN.md')!=read(root/'configs/PLAN_CHANGE.json')['revised_plan_sha256']:
        raise RuntimeError('Plan hash changed; record an explicit decision before continuing')
    if point['checker_hash']!=digest(CHECKER):
        raise RuntimeError('Frozen checker changed')
    if point['last_completed_run_id']:
        out=root/'runs'/point['last_completed_run_id']
        verify_seal(out)
        if digest(out/'RAW_COMPLETE.json')!=point['raw_seal_hash'] or not read(out/'validation.json')['passed']:
            raise RuntimeError('Last checkpoint no longer validates')
    pending=[]
    for run_id,entry in manifest['runs'].items():
        if entry['state'] in ['RUNNING','UNKNOWN']:
            pending.append(run_id)
    if verify_frozen:
        frozen=read(root/'configs/FROZEN_BASELINES.json')
        changed=[name for name,metadata in frozen['files'].items()
                 if not (root.parent/name).is_file() or digest(root.parent/name)!=metadata['sha256']]
        if changed:
            raise RuntimeError(f'Historical baseline changed: {changed[:10]}')
    return {'status':status,'checkpoint':point,'pending':pending,'plan_read':bool(plan)}
