"""Observe a selected actual transaction's successful exit without changing it."""
def wrap_exit(original, active):
    async def observed(transaction, exc_type, exc_value, traceback):
        result=await original(transaction,exc_type,exc_value,traceback)
        witness=active.get()
        if (exc_type is None and witness is not None and witness.get('transaction') is transaction
                and witness.get('apply_observed') and not witness.get('committed')):
            witness['committed']=True
            witness['on_commit']()
        return result
    return observed
