"""Fresh Phase-2 native Hindsight sessions and causal multi-source mapping."""
import asyncio
import copy
import contextvars
import hashlib
import time
from recovery.state import ROOT,append,atomic,utc
from multisource.oracle import check,recovery_contract
from workload.hindsight_base import Session as Base,ACTIVE_MUTATION

READ=contextvars.ContextVar('phase2_read_sql',default=None)

class Session(Base):
    def __init__(self,out,config):
        super().__init__(out.name,out);self.config=config;self.sources={};self.sql_reads=[];self.sql_originals={};self.sql_observer_overhead_ns=0
        self.native=out/'native';self.native.mkdir();self.seq=0
    async def open(self):
        await self.initialize()
        # Concurrent workers map the value actually read, never a sidecar head
        # that may already have advanced while the database query awaited.
        from workload.hindsight_base import old
        async def witnessed_source_read(**kwargs):
            result=await self.originals['find_unconsolidated'](**kwargs)
            if kwargs.get('bank_id')==self.bank and result:
                mapping={str(m.unit_id):self.raw_witnesses.get((str(m.unit_id),m.text)) for m in result}
                self.job_source_reads.setdefault(old.JOB.get(),{}).update(mapping)
                self.events.append(dict(event='native_worker_source_read',native_operation_id=old.JOB.get(),mapping=mapping,exact_native_values=[dict(native_id=str(m.unit_id),text=m.text) for m in result]))
                if self.source_gate is not None and not self.source_gate_used:
                    self.source_gate_used=True;self.source_gate_hit.set();await asyncio.wait_for(self.source_gate.wait(),30)
            return result
        self.store.find_unconsolidated=witnessed_source_read
        import asyncpg
        for name in ['fetch','fetchrow','fetchval']:
            original=getattr(asyncpg.Connection,name);self.sql_originals[name]=original
            async def observed(conn,query,*args,_original=original,_name=name,**kwargs):
                scope=READ.get()
                result=await _original(conn,query,*args,**kwargs)
                q=query.lstrip().upper()
                if scope and (q.startswith('SELECT') or q.startswith('WITH') and not any(w in q for w in ['INSERT ','UPDATE ','DELETE '])):
                    observer_started=time.perf_counter_ns()
                    event={'event':'sql_read','boundary':scope,'method':_name,'query_sha256':hashlib.sha256(query.encode()).hexdigest(),'at':utc()}
                    self.sql_reads.append(event);append(self.out/'sql_reads.jsonl',event)
                    self.sql_observer_overhead_ns+=time.perf_counter_ns()-observer_started
                return result
            setattr(asyncpg.Connection,name,observed)
    async def close(self):
        await super().close()
        import asyncpg
        for name,method in self.sql_originals.items():setattr(asyncpg.Connection,name,method)
    def targets(self):
        return [k for i,s in self.sources.items() if s['live'] for k in [f'A:{i}',f'S:{i}']]
    def publication(self,updates,revisions=()):
        if len(self.sources)<=1:return super().publication(updates,revisions)
        from multisource.publications import publish
        cid,added=publish(self.label,self.commits,self.revisions,updates,revisions)
        append(self.out/'publication_events.jsonl',{'at':utc(),'commit':self.commits[-1],'revisions':added,
            'dependency_basis':'Same logical publication chain plus actual raw/derived parent revisions; unrelated sources have no invented edge'})
        return cid
    async def create_source(self,index,text):
        self.mock_fact(text);ids=await self.operation(f'create_{index}',self.engine.retain_async(self.bank,text,document_id=f'source_{index}',request_context=self.ctx))
        assert len(ids)==1; nid=str(ids[0]);rid=f'a:{index}:1'
        self.sources[index]={'native_id':nid,'revision':1,'live':True};self.native_to_revision[nid]=rid
        self.publication({f'A:{index}':rid},[dict(logical_id=f'A:{index}',revision_id=rid,kind='raw',native_id=nid)])
        actual=await self.engine.get_memory_unit(self.bank,nid,request_context=self.ctx)
        self.register_witness(rid,nid,actual['text'],'Actual native retain ACK and canonical UUID/value')
    async def update_source(self,index,text,supersede=False):
        s=self.sources[index];self.raw_id=s['native_id'];previous=self.native_to_revision[self.raw_id];n=s['revision']+1;rid=f'a:{index}:{n}'
        if supersede:
            self.mock_fact(text);ids=await self.operation(f'supersede_{index}_{n}',self.engine.retain_async(self.bank,text,document_id=f'source_{index}',request_context=self.ctx))
            assert len(ids)==1;self.native_to_revision.pop(self.raw_id,None);self.raw_id=str(ids[0]);s['native_id']=self.raw_id
            self.native_to_revision[self.raw_id]=rid
            self.publication({f'A:{index}':rid,f'S:{index}':None},[dict(logical_id=f'A:{index}',revision_id=rid,kind='raw',native_id=self.raw_id,parent_revision=previous)])
            actual=await self.engine.get_memory_unit(self.bank,self.raw_id,request_context=self.ctx)
            self.register_witness(rid,self.raw_id,actual['text'],'Native document replacement ACK + canonical UUID/value')
        else:
            nid=self.raw_id
            def committed():
                self.native_to_revision[nid]=rid
                self.publication({f'A:{index}':rid,f'S:{index}':None},[dict(logical_id=f'A:{index}',revision_id=rid,kind='raw',native_id=nid,parent_revision=previous)])
                self.register_witness(rid,nid,text,'Successful exit of owning PostgreSQL native update transaction')
            witness={'text':text,'committed':False,'apply_observed':False,'transaction':None,'on_commit':committed}
            token=ACTIVE_MUTATION.set(witness)
            try:actual=await self.operation(f'update_{index}_{n}',self.engine.update_memory_unit(self.bank,nid,text=text,request_context=self.ctx))
            finally:ACTIVE_MUTATION.reset(token)
            if not actual or not witness['committed']:raise RuntimeError('Actual update transaction was not observed')
        s['revision']=n
    async def delete_source(self,index):
        s=self.sources[index];result=await self.operation(f'delete_{index}',self.engine.delete_document(document_id=f'source_{index}',bank_id=self.bank,request_context=self.ctx))
        if result.get('document_deleted')!=1:raise RuntimeError('Native delete not acknowledged')
        cid=self.publication({f'A:{index}':None,f'S:{index}':None});self.required_fences.append(cid);s['live']=False;self.native_to_revision.pop(s['native_id'],None)
    def observe_publications(self,completed_operations=None,returned_ids=None):
        known={r.get('native_id') for r in self.revisions if r['kind']=='derived'}
        completed={o['id'] for e in self.events if e.get('event')=='native_operation_status' for o in e['response'].get('operations',[]) if o['status']=='completed'}
        byrid={r['revision_id']:r for r in self.revisions}
        for e in self.insert_events:
            if e['native_id'] in known:continue
            if e['native_operation_id'] not in completed and e['native_id'] not in (returned_ids or set()):continue
            parents=[]
            for sid in e['source_ids']:
                rid=e['source_revisions'].get(sid)
                if rid not in byrid:self.mapping_uncertain=True;break
                parents.append({'logical_id':byrid[rid]['logical_id'],'revision_id':rid})
            else:
                logical='S:'+str(parents[0]['logical_id'].split(':')[1]) if len(parents)==1 else 'S:parents:'+'+'.join(sorted(p['logical_id'] for p in parents))
                rid='s:'+e['native_id']
                self.publication({logical:rid},[dict(logical_id=logical,revision_id=rid,kind='derived',native_id=e['native_id'],generation=e['native_id'],derived_from=parents)])
                known.add(e['native_id'])
    async def capture(self,label='read'):
        self.seq+=1;name=f'{label}_{self.seq:04d}';begin=time.perf_counter_ns();old_reads=len(self.sql_reads);token=READ.set(name)
        try:response=await self.engine.recall_async(self.bank,'Alice location',fact_type=['world','observation'],include_source_facts=True,include_entities=False,include_chunks=False,max_tokens=8192,reranking='rrf',request_context=self.ctx)
        finally:READ.reset(token)
        ended=time.perf_counter_ns();raw=response.model_dump(mode='json');atomic(self.native/f'{name}.native.json',raw)
        self.observe_publications(returned_ids={x['id'] for x in raw['results']});h=self.history();h['required_fences']=self.required_fences.copy()
        byrid={x['revision_id']:x for x in self.revisions};items=[];errors=[]
        for lane,facts in [('results',raw['results']),('source_facts',list((raw.get('source_facts') or {}).values()))]:
            for i,f in enumerate(facts):
                if f['fact_type']=='world':rid=self.raw_witnesses.get((f['id'],f['text']))
                else:
                    matched=[r for r in self.revisions if r.get('native_id')==f['id'] and r['kind']=='derived'];rid=matched[0]['revision_id'] if len(matched)==1 else None
                if rid not in byrid:errors.append({'id':f['id'],'reason':'Missing exact immutable source/parent witness'});continue
                r=byrid[rid];item=dict(logical_id=r['logical_id'],revision_id=rid,role='current',native_id=f['id'],native_path=f'{lane}.{i}')
                if r['kind']=='derived':item['generation']=r['generation']
                items.append(item)
        recall={'mapping_complete':not errors and not self.mapping_uncertain,'native_boundary':'MemoryEngine.recall_async/world,observation/include_source_facts','items':items,'required_coverage':self.targets(),
                'coverage_scope':'Declared live source + observation representation targets; eligibility proxy'}
        verdict=check(h,recall);v={'name':name,'history':h,'recall':recall,'verdict':verdict,'contract':recovery_contract(h,recall,verdict),'mapping_errors':errors,
                'native_start_ns':begin,'native_end_ns':ended,'native_latency_ms':(ended-begin)/1e6,'backend_reads':len(self.sql_reads)-old_reads,'backend_read_scope':'Observed read-only asyncpg fetch/fetchrow/fetchval calls','extra_canonical_fetches':0}
        atomic(self.native/f'{name}.sidecar.json',v);v['native_payload']=raw
        v['cost_categories']={'sql_reads':len(self.sql_reads)-old_reads,'native_recall_calls':1,'canonical_reads':0}
        append(self.out/'read_events.jsonl',{'event':'native_read','name':name,'native_end_ns':ended,'status':verdict['status'],'native_latency_ms':v['native_latency_ms'],'backend_reads':v['backend_reads'],'at':utc()})
        return v
    async def hydration(self,v):
        from mitigations.publication import filtered
        begin=time.perf_counter_ns();value=filtered(v);items=[x for x in value['recall']['items'] if not x['logical_id'].startswith('A:')];fetches=[]
        ids={x['native_id'] for x in v['recall']['items'] if x['logical_id'].startswith('A:')}
        token=READ.set('hydration');old_reads=len(self.sql_reads)
        try:
            for nid in sorted(ids):
                raw=await self.engine.get_memory_unit(self.bank,nid,request_context=self.ctx);fetches.append({'native_id':nid,'result':raw})
                if raw:
                    rid=self.raw_witnesses.get((nid,raw['text']));rev=next((r for r in self.revisions if r['revision_id']==rid),None)
                    if rev:items.append({'logical_id':rev['logical_id'],'revision_id':rid,'role':'current','native_id':nid,'native_path':'actual_canonical_get'})
                    else:value['recall']['mapping_complete']=False
        finally:READ.reset(token)
        value['recall']['items']=items;h=self.history();h['required_fences']=self.required_fences.copy();value['history']=h
        restored={x['logical_id'] for x in items}
        value['recall']['hidden_eligible']=[x for x in value['recall'].get('hidden_eligible',[]) if x not in restored]
        value['canonical_payload']=fetches
        value['verdict']=check(h,value['recall']);value['contract']=recovery_contract(h,value['recall'],value['verdict'])
        value.update(extra_canonical_fetches=len(fetches),extra_backend_reads=len(self.sql_reads)-old_reads,hydration_ms=(time.perf_counter_ns()-begin)/1e6)
        atomic(self.out/f'hydration_{self.seq:04d}.evidence.json',{'fetches':fetches,'value':value})
        return value
