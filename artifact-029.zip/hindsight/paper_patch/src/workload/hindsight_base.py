"""Phase-1-owned runtime configuration; frozen native methods and offline fixture."""
import asyncio
import copy
import contextvars
import importlib.util
import json
import os
import random
from pathlib import Path
import sys
import time
from uuid import uuid4
from recovery.state import ROOT, append, atomic, read, seal, utc

sys.path.insert(0,str(ROOT.parent/'src'))
from adapters import hindsight_local as old
from runner.validation import core
from workload.transaction_observer import wrap_exit
ACTIVE_MUTATION=contextvars.ContextVar('phase1_native_mutation',default=None)

class DurableEvents(list):
    def __init__(self,path):
        super().__init__();self.path=path
    def append(self,value):
        observer_started=time.perf_counter_ns()
        super().append(value)
        append(self.path,{'seq':len(self),'at':utc(),**value})
        self.observer_overhead_ns=getattr(self,'observer_overhead_ns',0)+(time.perf_counter_ns()-observer_started)

class Session(old.NativeSession):
    def __init__(self,label,out):
        self.label=label; self.bank=f'torn-phase3-{label}-{uuid4().hex[:8]}'; self.ctx=old.RequestContext()
        runtime=read(ROOT/'configs/database_runtime.json')
        self.engine=old.MemoryEngine(db_url=f"postgresql://anonymous:LOCAL_FIXTURE_PASSWORD@127.0.0.1:{runtime['port']}/torn_phase3",
            memory_llm_provider='mock',memory_llm_model='mock-model',memory_llm_api_key='unused-offline-fixture',
            embeddings=old.FixtureEmbeddings(),cross_encoder=old.RRFPassthroughCrossEncoder(),pool_min_size=2,pool_max_size=8)
        self.events=DurableEvents(out/'backend_events.jsonl');self.insert_events=DurableEvents(out/'observation_inserts.jsonl');self.native_to_revision={}
        self.revisions=[];self.commits=[];self.raw_id=None;self.store=None;self.originals={};self.poller=None
        self.read_gate=None;self.read_gate_hit=None;self.source_read_mapping={};self.source_gate=None
        self.source_gate_hit=None;self.source_gate_used=False;self.job_source_reads={};self.required_fences=[]
        self.mapping_uncertain=False;self.out=out
        self.raw_witnesses={};self.read_counter=0
        self.original_transaction_exit=None

    async def initialize(self):
        await super().initialize()
        import asyncpg.transaction
        self.original_transaction_exit=asyncpg.transaction.Transaction.__aexit__
        asyncpg.transaction.Transaction.__aexit__=wrap_exit(self.original_transaction_exit,ACTIVE_MUTATION)
        original=self.store.apply_edit;self.originals['apply_edit']=original
        async def apply_edit(*args,**kwargs):
            witness=ACTIVE_MUTATION.get()
            result=await original(*args,**kwargs)
            if witness and kwargs.get('bank_id')==self.bank and kwargs.get('unit_id')==self.raw_id:
                if kwargs.get('text')!=witness['text']:raise RuntimeError('Native edit disagrees with observed intent')
                connection=getattr(kwargs['conn'],'_conn',kwargs['conn'])
                connection=getattr(connection,'_con',connection)
                witness['transaction']=getattr(connection,'_top_xact',None)
                if witness['transaction'] is None:raise RuntimeError('Native transaction identity unavailable')
                witness['apply_observed']=True
            return result
        self.store.apply_edit=apply_edit

    async def close(self):
        try:await super().close()
        finally:
            if self.original_transaction_exit:
                import asyncpg.transaction
                asyncpg.transaction.Transaction.__aexit__=self.original_transaction_exit

    def publication(self,updates,revisions=()):
        result=super().publication(updates,revisions)
        append(self.out/'publication_events.jsonl',{'at':utc(),'commit':self.commits[-1],'revisions':[r for r in self.revisions if r['commit_id']==result]})
        return result

    async def operation(self,name,call):
        append(self.out/'intent.jsonl',{'event':'intent','operation':name,'bank':self.bank,'at':utc()})
        t=time.perf_counter()
        result=await call
        append(self.out/'operation_acks.jsonl',{'operation':name,'elapsed_ms':(time.perf_counter()-t)*1000,'result':result,'at':utc()})
        return result

    def register_witness(self,revision_id,native_id,text,basis):
        self.raw_witnesses[(str(native_id),text)]=revision_id
        append(self.out/'raw_revision_witnesses.jsonl',{'revision_id':revision_id,'native_id':str(native_id),'exact_text':text,'basis':basis})

    async def mutate(self,text,family):
        previous=self.native_to_revision[self.raw_id]
        generation=sum(r['logical_id']=='A' for r in self.revisions)+1
        rid=f'a{generation}'
        if family=='update':
            native_id=self.raw_id
            def committed():
                self.native_to_revision[native_id]=rid
                self.publication({'A':rid,'S':None},[dict(logical_id='A',revision_id=rid,kind='raw',native_id=native_id,parent_revision=previous,changed_fields=['text'])])
                self.register_witness(rid,native_id,text,'Actual native apply_edit followed by successful exit of its owning PostgreSQL write transaction')
                self.events.append({'event':'native_write_transaction_commit_ack','revision_id':rid,'native_id':native_id})
            witness={'text':text,'committed':False,'apply_observed':False,'transaction':None,'on_commit':committed}
            token=ACTIVE_MUTATION.set(witness)
            try:response=await self.engine.update_memory_unit(self.bank,self.raw_id,text=text,request_context=self.ctx)
            finally:ACTIVE_MUTATION.reset(token)
            if response is None:raise RuntimeError('Native update did not acknowledge the fixture record')
            if not witness['committed']:raise RuntimeError('Native write commit was not observed; mapping incomplete')
            native_id=self.raw_id; witness=response['text']
        else:
            self.mock_fact(text)
            ids=await self.engine.retain_async(self.bank,text,document_id='alice_location',request_context=self.ctx)
            if len(ids)!=1 or str(ids[0])==self.raw_id:raise RuntimeError('Native replacement identity unexpected')
            old_id=self.raw_id;self.native_to_revision.pop(old_id,None)
            native_id=str(ids[0]);self.raw_id=native_id
            response=await self.engine.get_memory_unit(self.bank,native_id,request_context=self.ctx)
            witness=response['text']
        if family!='update':
            self.native_to_revision[native_id]=rid
            self.publication({'A':rid,'S':None},[dict(logical_id='A',revision_id=rid,kind='raw',native_id=native_id,parent_revision=previous,changed_fields=['text'])])
            self.register_witness(rid,native_id,witness,'native mutation acknowledgement/get after document replacement')
        self.events.append({'event':'phase1_native_mutation_ack','revision_id':rid,'response':response,'family':family})

    async def capture(self,native,kind='read'):
        self.read_counter+=1;name=f'{kind}_{self.read_counter:04d}'
        append(self.out/'read_events.jsonl',{'event':'read.begin','name':name,'at':utc()})
        t=time.perf_counter()
        result=await self.engine.recall_async(self.bank,'Alice location',fact_type=['world','observation'],include_source_facts=True,
            include_entities=False,include_chunks=False,max_tokens=4096,reranking='rrf',request_context=self.ctx)
        latency=(time.perf_counter()-t)*1000
        raw=result.model_dump(mode='json');atomic(native/f'{name}.native.json',raw)
        # A returned immutable observation UUID witnesses an actual committed
        # publication even while the native worker is finishing its bookkeeping.
        # Its parents still come from the actual recorded worker source read.
        returned={fact['id'] for fact in raw['results'] if fact['fact_type']=='observation'}
        known={r.get('native_id') for r in self.revisions}
        for event in self.insert_events:
            if event['native_id'] not in returned or event['native_id'] in known:continue
            parents=event['source_revisions']
            if len(parents)!=1 or next(iter(parents.values())) not in {r['revision_id'] for r in self.revisions}:continue
            parent=next(iter(parents.values()));rid='s:'+event['native_id']
            self.native_to_revision[event['native_id']]=rid
            self.publication({'S':rid},[dict(logical_id='S',revision_id=rid,kind='derived',native_id=event['native_id'],generation=event['native_id'],
                parent_revision=None,changed_fields=['text','sources'],derived_from=[dict(logical_id='A',revision_id=parent)],
                observed_native_publication=event,publication_witness='Native recall returned the committed immutable observation UUID')])
            known.add(event['native_id'])
        history=self.history();history['required_fences']=self.required_fences.copy()
        revisions={r['revision_id']:r for r in self.revisions}
        items=[];mapping_errors=[]
        for location,facts in [('results',raw['results']),('source_facts',list((raw.get('source_facts') or {}).values()))]:
            for fact in facts:
                if fact['fact_type']=='world':
                    rid=self.raw_witnesses.get((fact['id'],fact['text']))
                else:
                    matches=[r for r in self.revisions if r['native_id']==fact['id'] and r['kind']=='derived']
                    rid=matches[0]['revision_id'] if len(matches)==1 else None
                if rid not in revisions:
                    mapping_errors.append({'native_id':fact['id'],'location':location,'reason':'No unique already-observed immutable revision witness'})
                    continue
                rev=revisions[rid];item=dict(logical_id=rev['logical_id'],revision_id=rid,native_id=fact['id'],role='current',native_location=location)
                if rev['kind']=='derived':item['generation']=rev['generation']
                items.append(item)
        annotated=dict(native_boundary='MemoryEngine.recall_async(types=world,observation;include_source_facts=True)',mapping_complete=not mapping_errors and not self.mapping_uncertain,
            items=items,required_coverage=[] if self.required_fences else ['A','S'])
        value=dict(system='Hindsight',is_native_experiment=True,native_output=f'{name}.native.json',history=history,recall=annotated,
            verdict=core.check(history,annotated),mapping_errors=mapping_errors,read_latency_ms=latency,
            mapping_basis='Native UUID plus byte-exact acknowledged fixture value for mutable raw records; observed immutable observation UUID and job parent read for derived records. No semantic/text-conflict judge.')
        atomic(native/f'{name}.sidecar.json',value)
        append(self.out/'read_events.jsonl',{'event':'read.return','name':name,'verdict':value['verdict']['status'],'elapsed_ms':latency,'at':utc()})
        return value

async def concurrent(s,native,config,initial):
    for fact in initial['history']['revisions']:
        if fact['kind']=='raw':
            raw=read(native/'B1_create.native.json')
            match=next(x for x in raw['results'] if x['id']==fact['native_id'])
            s.register_witness(fact['revision_id'],fact['native_id'],match['text'],'initial native baseline UUID/value')
    done=asyncio.Event();rows=[];retries=[]
    rng=random.Random(config['seed']);gap=config['writer_gap_ms']/1000
    async def writer():
        try:
            await asyncio.sleep(rng.uniform(0,.01))
            family=config['operation_family']
            versions=['San Francisco','Boston','Denver','Austin','Miami','Chicago']
            texts=[f'Alice lives in {city}.' for city in versions[:config.get('logical_revisions',3)-1]]
            for i,text in enumerate(texts):
                if i and gap:await asyncio.sleep(gap)
                if family=='delete' and i==1:
                    await s.operation('delete_v2',s.delete());await s.operation('drain_delete',s.drain())
                else:
                    await s.operation(f'mutate_{i+2}',s.mutate(text,'supersede' if family=='supersede' else 'update'))
                    await s.operation(f'derive_{i+2}',s.drain())
        finally:done.set()
    task=asyncio.create_task(writer())
    while not done.is_set() and len(rows)<config['max_recalls']:
        first=await s.capture(native);rows.append(first)
        if config['mitigation']=='retry' and first['verdict']['status']=='TORN':
            attempt=[]
            for _ in range(config['retry_budget']):
                value=await s.capture(native,'retry');rows.append(value);attempt.append(value)
                if value['verdict']['status'] in ['PASS','STALE','COVERAGE_MISS']:break
            retries.append({'original':first['native_output'],'attempts':[v['native_output'] for v in attempt],
                'retry_count':len(attempt),'recovered':bool(attempt and attempt[-1]['verdict']['status'] in ['PASS','STALE','COVERAGE_MISS']),
                'full_coverage':bool(attempt and attempt[-1]['verdict']['status'] in ['PASS','STALE']),
                'latency_ms':sum(v['read_latency_ms'] for v in attempt)})
        await asyncio.sleep(0)
    await task
    rows.append(await s.capture(native,'recovery'))
    atomic(s.out/'retry_outcomes.json',retries)
    return rows,retries

async def execute(out,config):
    if config['workload']=='native_crash_recover':
        from workload.native_recovery import execute as recovery
        return await recovery(out,config)
    native=out/'native';native.mkdir(exist_ok=False)
    s=Session(config['operation_family']+'-'+str(config['seed']),out)
    rows=[]
    try:
        await s.operation('initialize',s.initialize())
        atomic(out/'IDENTITY.json',{'bank_id':s.bank,'system':'Hindsight','version':'0.10.2','commit':'9269b88417ed263e5a8350f2e416ca2b322756b1','paid_llm_calls':0})
        if config['workload']=='population_feasibility':
            from workload.population_probe import hindsight,finish
            await hindsight(s,out,config);finish(out,'Hindsight');return
        if config['workload']=='native_crash_prepare':
            from workload.native_recovery import prepare
            return await prepare(s,out,native,config)
        await s.operation('create_v1',s.create());await s.operation('derive_v1',s.drain())
        rows.append(await s.operation('recall_create',s.recall(native,'B1_create')))
        family=config['operation_family']
        if config['workload']=='positive_control':
            for fact in read(native/'B1_create.native.json')['results']:
                if fact['fact_type']=='world':s.register_witness('a1',fact['id'],fact['text'],'initial native baseline')
            s.read_gate=asyncio.Event();s.read_gate_hit=asyncio.Event()
            task=asyncio.create_task(s.capture(native,'controlled'))
            await asyncio.wait_for(s.read_gate_hit.wait(),20)
            await s.operation('control_update',s.mutate('Alice lives in San Francisco.','update'))
            await s.operation('control_derive',s.drain())
            s.read_gate.set();rows.append(await asyncio.wait_for(task,20));s.read_gate=None
            rows.append(await s.capture(native,'retry'));rows.append(await s.capture(native,'recovery'))
            if rows[1]['verdict']['status']!='TORN':raise RuntimeError('Known positive control not detected')
            from mitigations.control_study import hindsight_study
            await hindsight_study(s,native,rows[1],rows[2])
        elif config['workload']=='late_job_control':
            s.source_gate=asyncio.Event();s.source_gate_hit=asyncio.Event();s.source_gate_used=False
            # Use a new source update to enqueue real derived work before deletion.
            await s.operation('late_update_v2',s.update())
            task=asyncio.create_task(s.drain())
            await asyncio.wait_for(s.source_gate_hit.wait(),20)
            await s.operation('delete_before_old_job_finishes',s.delete())
            s.source_gate.set();await asyncio.wait_for(task,30);s.source_gate=None
            rows.append(await s.operation('recall_after_late_job',s.recall(native,'late_job_delete',required=())))
        elif config['workload']!='baseline':
            extra,retries=await concurrent(s,native,config,rows[0]);rows.extend(extra)
        elif family=='update':
            await s.operation('update_v2',s.update());await s.operation('derive_v2',s.drain())
            rows.append(await s.operation('recall_update',s.recall(native,'B2_update')))
        elif family=='supersede':
            await s.operation('supersede_v2',s.replace());await s.operation('derive_v2',s.drain())
            rows.append(await s.operation('recall_supersede',s.recall(native,'B4_supersede')))
        elif family=='delete':
            await s.operation('delete_v1',s.delete());await s.operation('drain_delete',s.drain())
            rows.append(await s.operation('recall_delete',s.recall(native,'B3_delete',required=())))
        else:
            raise RuntimeError('Workload not implemented; no fabricated experiment')
    finally:
        await s.close()
    files=list(native.glob('*.json'))+list(out.glob('*.jsonl'))+[out/'IDENTITY.json']
    if (out/'retry_outcomes.json').exists():files.append(out/'retry_outcomes.json')
    counts={key:sum(r['verdict']['status']==key for r in rows) for key in ['PASS','STALE','COVERAGE_MISS','TORN','UNKNOWN']}
    seal(out,files,True,{'system':'Hindsight','native_calls':len(rows),'classifications':counts,'read_latency_ms':[r['read_latency_ms'] for r in rows],
        'retry_outcomes':read(out/'retry_outcomes.json') if (out/'retry_outcomes.json').exists() else [],
        'forced_read_pause':config['workload']=='positive_control','writer_gap_ms':config.get('writer_gap_ms'),'logical_revisions':sum(r['logical_id']=='A' for r in s.revisions),
        'scientific_scope':'Native local PostgreSQL/worker/recall with frozen offline AI fixtures; bounded history in CONFIG.json; no production prevalence or performance claim.'})
