"""Native sidecar publication dependencies, without unrelated source serialization."""
def publish(label,commits,revisions,updates,new_revisions=()):
    cid=f'{label}:commit:{len(commits)+1}';parents=set()
    byrid={r['revision_id']:r for r in revisions}
    for logical in updates:
        previous=next((c for c in reversed(commits) if logical in c['updates']),None)
        if previous:parents.add(previous['commit_id'])
    for r in new_revisions:
        refs=[d['revision_id'] for d in r.get('derived_from',[])]
        if r.get('parent_revision'):refs.append(r['parent_revision'])
        for rid in refs:parents.add(byrid[rid]['commit_id'])
    commits.append({'commit_id':cid,'parents':sorted(parents),'updates':updates})
    added=[{**r,'commit_id':cid,'provenance_complete':True} for r in new_revisions];revisions.extend(added)
    return cid,added
