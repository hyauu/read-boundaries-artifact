"""Exact dependency-cut satisfiability without enumerating all committed cuts.

The structural validator is a Phase-2 copy of the frozen core, with a larger
computational bound. Each current revision prohibits every later same-object
write; descendants of prohibited events must also be absent. The maximal
remaining causally closed cut exists iff it includes every required publication
and lifecycle fence and explains every pinned revision. Historical citations
are checked separately without current fences, exactly as in the frozen core.
"""
from dataclasses import asdict
from .validated_history import History,IncompleteModel,Verdict,_require


def witness(model,refs,fences):
    pins={};publications=set()
    for r in refs:
        logical,rid=r['logical_id'],r['revision_id']
        if logical in pins and pins[logical]!=rid:return None
        pins[logical]=rid;publications.add(r['commit_id'])
    forbidden=set()
    for logical,rid in pins.items():
        first=model.revisions[rid]['commit_id']
        for cid,c in model.commits.items():
            if cid in model.frontier and logical in c['updates'] and first in model.ancestors[cid]:
                forbidden.add(cid)
    cut={cid for cid in model.frontier if cid not in forbidden and not (model.ancestors[cid]&forbidden)}
    if not (publications|set(fences))<=cut:return None
    state={}
    for cid,c in model.commits.items():
        if cid in cut:state.update(c['updates'])
    if any(state.get(k)!=r for k,r in pins.items()):return None
    return cut


def check(history,recall):
    try:
        _require(recall.get('mapping_complete') is True,'Native-result provenance mapping is incomplete')
        _require(bool(recall.get('native_boundary')),'No native recall boundary recorded')
        model=History(history);returned=set();current=[]
        for item in recall['items']:
            refs=model.revision_closure(item['revision_id']);r=refs[0]
            _require(item['logical_id']==r['logical_id'],'Native item logical ID mismatch')
            if r['kind']=='derived':_require(item.get('generation')==r['generation'],'Native item generation missing/mismatch')
            role=item['role'];_require(role in ('current','historical'),'Native authority role is not established')
            returned.add(item['logical_id'])
            if role=='current':current.extend(refs)
            else:_require(witness(model,refs,[]) is not None,'Historical citation has no established committed dependency basis')
        missing=sorted(set(recall.get('required_coverage',[]))-returned)
        cut=witness(model,current,model.fences)
        if cut is None:return asdict(Verdict('TORN','No legal committed dependency cut explains the current bundle',
                   missing_coverage=missing,compatible_at_frontier=False,legal_cuts_examined=1))
        fresh=cut==model.frontier
        status='COVERAGE_MISS' if missing else ('PASS' if fresh else 'STALE')
        reason=('Compatible bundle misses declared coverage targets' if missing else
                'Bundle is compatible with the observed committed frontier' if fresh else
                'Bundle is compatible with an older committed cut')
        return asdict(Verdict(status,reason,sorted(cut),missing,fresh,1))
    except (IncompleteModel,KeyError,TypeError,ValueError,RecursionError) as exc:
        return asdict(Verdict('UNKNOWN',str(exc)))


def recovery_contract(history,recall,verdict=None,freshness_bound=0):
    """C2 counts eligible current coverage; C3 separately enforces freshness."""
    verdict=verdict or check(history,recall)
    known=verdict['status']!='UNKNOWN'
    compatible=known and verdict['status']!='TORN'
    required=set(recall.get('required_coverage',[]))
    returned={x['logical_id'] for x in recall.get('items',[]) if x['role']=='current'}
    covered=required&returned
    coverage=len(covered)/len(required) if required and known else (1.0 if known else None)
    full=compatible and required<=returned and not recall.get('hidden_eligible',[])
    lag=None
    if known:
        model=History(history);heads={};order={}
        for cid,c in model.commits.items():
            if cid in model.frontier:heads.update(c['updates'])
        for r in model.revisions.values():
            if r['kind']=='raw':order.setdefault(r['logical_id'],[]).append(r['revision_id'])
        lags=[]
        for item in recall.get('items',[]):
            if item['role']!='current':continue
            for r in model.revision_closure(item['revision_id']):
                if r['kind']=='raw':
                    h=heads.get(r['logical_id']);versions=order[r['logical_id']]
                    if h in versions:lags.append(versions.index(h)-versions.index(r['revision_id']))
        lag=max(lags) if lags else (0 if not required else None)
    coverage_full=full
    full=coverage_full and lag is not None and lag<=freshness_bound
    return {'compatible':compatible,'coverage_full':coverage_full,'full':full,'fresh_full':full,
            'coverage':coverage,'missing_current':sorted(required-returned),'revision_lag':lag,
            'coverage_scope':recall.get('coverage_scope','Declared logical representation targets; coverage proxy'),
            'hidden_eligible':recall.get('hidden_eligible',[]),'known':known}
