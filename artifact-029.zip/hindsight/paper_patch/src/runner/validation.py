from types import SimpleNamespace
from multisource.oracle import check
from multisource.validated_history import History
core=SimpleNamespace(check=check,History=History)
