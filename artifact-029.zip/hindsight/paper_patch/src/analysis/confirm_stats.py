"""Frozen run-level estimates. None is never silently imputed as zero."""
import math,random,statistics

def median(values):
    v=[x for x in values if x is not None]
    return statistics.median(v) if v else None
def quantile(values,p):
    v=sorted(values)
    if not v:return None
    pos=(len(v)-1)*p;i=int(pos);j=min(i+1,len(v)-1)
    return v[i]+(v[j]-v[i])*(pos-i)
def summary(values,draws=10000,alpha=.05):
    v=[x for x in values if x is not None]
    if not v:return dict(n=0,median=None,q1=None,q3=None,ci_low=None,ci_high=None)
    rng=random.Random(7302026);samples=[median(rng.choices(v,k=len(v))) for _ in range(draws)]
    return dict(n=len(v),median=median(v),q1=quantile(v,.25),q3=quantile(v,.75),ci_low=quantile(samples,alpha/2),ci_high=quantile(samples,1-alpha/2))
def run_recovery(result):
    return {k:median([e.get(k) for e in result.get('recovery_events',[])]) for k in ['T_compatible_ms','T_full_ms','RecoveryGap_ms','N_compatible','N_full']}
def sign_test(differences):
    v=[x for x in differences if x is not None and x!=0]
    n=len(v);pos=sum(x>0 for x in v);negative=n-pos
    p=min(1,2*sum(math.comb(n,k) for k in range(min(pos,negative)+1))/(2**n)) if n else None
    return dict(n_nonzero=n,positive=pos,negative=negative,two_sided_exact_p=p)
