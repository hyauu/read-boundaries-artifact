# Snapshot confirmation amendment v2

After all ten v1 known-witness pairs completed, the first v1 natural baseline seed 5001 stopped at an erroneous terminal `status == PASS` guard. Its 15 acknowledged updates, 127 stream recalls, native final payload, sidecar, trace and failure are retained under the original FAILED identity. It is excluded from primary natural estimates and remains inspectable diagnostic evidence; no rerun overwrites it.

The terminal response has `status=STALE`, compatible=true, full coverage, source revision lag=0 and frozen C2=true. An older derived generation with the same latest raw parents can satisfy C2. Requiring frontier-compatible PASS imposes a stronger condition than the frozen C2 definition. The correction tests only frozen C2. No checker, payload, coverage denominator, pacing, run length, retry budget or snapshot primitive changed.

The 20 already completed v1 witness units stay in their versioned witness block. Archived v1 native workload/repair/runner bytes are in `code_v1/`; the original preregistration is preserved. Two natural DEV units with seed 5091 check the terminal correction. The remaining confirmation families receive a separately frozen v2 protocol: 20 natural pairs with new seeds 5101–5120 and five no-write/read-heavy pairs 6101–6105. The causal workload and measurement budgets are unchanged. No additional repetitions will be added to improve the result.

This is a harness guard error, not evidence that a shared snapshot failed. Native outcomes, including STALE or residual TORN, remain scientific measurements.
