"""Finite native snapshot tests, with unchanged payloads and frozen checker."""
import asyncio,random,time
from collections import Counter
from snapshot_fix.repair import Session
from recovery.state import append,atomic,seal

async def execute(out,cfg):
    s=Session(out,cfg);rows=[];writes=[];trace=[];tasks=[];stop=asyncio.Event()
    def mark(name,**details):
        entry=dict(event=name,ns=time.perf_counter_ns(),**details);trace.append(entry);append(out/'schedule.jsonl',entry)
    def text(rev):return f'Alice lives in FixtureCity{rev:03d}. Source 0, revision {rev}. History {cfg["seed"]}.'
    async def update(rev,supersede=False):
        began=time.perf_counter_ns();await s.update_source(0,text(rev),supersede=supersede)
        e=dict(revision=rev,start_ns=began,end_ns=time.perf_counter_ns(),payload=text(rev));writes.append(e);append(out/'writes.jsonl',e)
    try:
        await s.open();await s.create_source(0,'Alice lives in Seattle. Source 0, revision 1.');await s.drain()
        baseline=await s.capture('baseline');rows.append(baseline)
        if baseline['verdict']['status']!='PASS' or not baseline['contract']['full']:raise RuntimeError('Baseline is not full/fresh')
        if cfg['family']=='WITNESS':
            prelude=cfg['template']=='SUPERSEDE';partial=cfg['template'] in ['PARTIAL','CONTINUOUS']
            if prelude:await update(2,True);await s.drain()
            target=3 if prelude or cfg['template']=='CONTINUOUS' else 2
            s.read_gate=asyncio.Event();s.read_gate_hit=asyncio.Event()
            reading=asyncio.create_task(s.capture('crossing'));tasks.append(reading)
            await asyncio.wait_for(s.read_gate_hit.wait(),20);mark('OLD_MAIN_RETRIEVAL_CAPTURED')
            if cfg['template']=='CONTINUOUS':await update(2);await s.drain();mark('INTERMEDIATE_DERIVATION_FULL')
            await update(target);mark('TARGET_SOURCE_COMMITTED')
            pending=None
            if partial:
                s.source_gate=asyncio.Event();s.source_gate_hit=asyncio.Event();s.source_gate_used=False
                pending=asyncio.create_task(s.drain());tasks.append(pending)
                await asyncio.wait_for(s.source_gate_hit.wait(),20);mark('TARGET_DERIVATION_HELD')
            else:await s.drain();mark('TARGET_DERIVATION_FULL')
            s.read_gate.set();crossing=await reading;rows.append(crossing);mark('CROSSING_RETURNED',status=crossing['verdict']['status'])
            s.read_gate=None
            if partial:s.source_gate.set();await pending
            await s.drain()
        elif cfg['family']=='NATURAL':
            started=time.perf_counter_ns();done=asyncio.Event();rng=random.Random(cfg['seed'])
            async def worker():
                while not stop.is_set():
                    for job in await s.poller.claim_batch():await s.poller.execute_task(job)
                    await asyncio.sleep(.02)
            async def writer():
                try:
                    await asyncio.sleep(rng.uniform(0,.01))
                    for rev in range(2,cfg['min_writes']+2):
                        await update(rev)
                        if rev<cfg['min_writes']+1:await asyncio.sleep(cfg['writer_interval_ms']/1000)
                finally:done.set()
            serving=asyncio.create_task(worker());writing=asyncio.create_task(writer());tasks.extend([serving,writing])
            while True:
                value=await s.capture('read');rows.append(value)
                elapsed=(value['native_end_ns']-started)/1e9
                if done.is_set() and len(rows)-1>=cfg['min_recalls'] and elapsed>=cfg['min_duration_seconds']:break
                if elapsed>cfg['max_duration_seconds']:raise RuntimeError('Frozen natural cap exhausted')
                await asyncio.sleep(cfg['reader_interval_ms']/1000)
            await writing;stop.set();await serving;await s.drain()
            if len(writes)!=cfg['min_writes']:raise RuntimeError('Missing native update ACK')
        else:
            for _ in range(cfg['warmup_recalls']):await s.capture('warmup')
            rows=[];started=time.perf_counter_ns()
            for _ in range(cfg['measured_recalls']):rows.append(await s.capture('read'))
            measurement_seconds=(time.perf_counter_ns()-started)/1e9
        stream=rows[1:] if cfg['family']!='READ_HEAVY' else rows[:]
        final=await s.capture('final')
        # C2 is the frozen contract, not a requirement that the latest derived
        # generation be present. A compatible older generation can have lag 0.
        if not final['contract']['full']:raise RuntimeError('Terminal native validation not frozen C2')
        result=dict(passed=True,family=cfg['family'],variant=cfg['variant'],seed=cfg['seed'],stage=cfg['stage'],
                    classifications=dict(Counter(x['verdict']['status'] for x in stream)),recalls=len(stream),writes=len(writes),
                    torn_run=any(x['verdict']['status']=='TORN' for x in stream),unknown_run=any(x['verdict']['status']=='UNKNOWN' for x in stream),
                    cross_read_status=stream[-1]['verdict']['status'] if cfg['family']=='WITNESS' else None,
                    final_status=final['verdict']['status'],final_C2=final['contract']['full'],
                    snapshot_import_transactions=len(s.snapshot_transactions),
                    all_snapshot_memberships_recorded=cfg['variant']=='baseline' or all(x.get('snapshot_id') and x.get('snapshot_transactions') for x in rows+[final]),
                    logical_history=[w['payload'] for w in writes],causal_events=[e['event'] for e in trace if e['event']!='CROSSING_RETURNED'],
                    measurement_seconds=measurement_seconds if cfg['family']=='READ_HEAVY' else None,
                    no_payload_edit=True,no_worker_wait_in_repair=True,parallel_exported_snapshot=cfg['variant']=='snapshot')
        atomic(out/'rows.evidence.json',[{k:v for k,v in r.items() if k!='native_payload'} for r in stream])
        atomic(out/'experiment_result.json',result)
        files=list((out/'native').glob('*.json'))+list(out.glob('*.jsonl'))+[out/'rows.evidence.json',out/'experiment_result.json']
        seal(out,files,True,result)
        return result
    finally:
        stop.set()
        if getattr(s,'read_gate',None):s.read_gate.set()
        if getattr(s,'source_gate',None):s.source_gate.set()
        for task in tasks:
            if not task.done():task.cancel()
        if tasks:await asyncio.gather(*tasks,return_exceptions=True)
        await s.close()
