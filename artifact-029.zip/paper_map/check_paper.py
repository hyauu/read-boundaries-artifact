"""Reconstruct paper counts from exported full tables; not new experiment execution."""
from pathlib import Path
from collections import defaultdict,Counter
import argparse,csv,json,statistics,math

def rows(p):return list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);a=ap.parse_args();r=a.root
    units=rows(r/'cognee/analysis/final/unit_metrics.csv')
    groups=defaultdict(Counter)
    for u in units:
        if u['block'] not in ['A','B'] or (u['block']=='A' and u['stage']!='primary'):continue
        k=(u['block'],u['requested_mode'],u['stratum'],u['strategy']);c=groups[k];c['runs']+=1
        for key in ['planned_requests','usable','direct_conflicts','partial','native_error','queue_rejected','native_calls','discarded_attempts']:c[key]+=int(u[key])
    B=[dict(block=k[0],mode=k[1],stratum=k[2],policy=k[3],**v) for k,v in groups.items() if k[0]=='B']
    assert len(B)==20 and sum(x['planned_requests'] for x in B)==240200
    assert sum(x['queue_rejected'] for x in B)==14606
    for x in B:
        assert x['runs']==10 and x['planned_requests']==12010
        if x['mode']=='DEFAULT_REQUEST' and x['policy'] in ['COORDINATED','EPOCH_VALIDATED']:assert x['usable']==12010
    assert sorted(x['direct_conflicts'] for x in B if x['mode']=='DEFAULT_REQUEST' and x['policy']=='NATIVE')==[199,284]
    A=[dict(block=k[0],mode=k[1],order=k[2],policy=k[3],**v) for k,v in groups.items() if k[0]=='A']
    assert len(A)==16 and all(x['runs']==20 and x['planned_requests']==20 for x in A)
    for x in A:
        if x['policy'] in ['COORDINATED','EPOCH_VALIDATED']:assert x['usable']==20
        elif x['mode']=='DEFAULT_REQUEST':assert x['direct_conflicts' if x['order']=='AR' else 'usable']==20
        elif x['policy']=='NATIVE' and x['order']=='AR':assert x['direct_conflicts']==20
        else:assert x['partial']==20
    h=r/'hindsight/paper_patch/snapshot_fix';rr=rows(h/'results.csv');ll=rows(h/'latency.csv');assert len(rr)==len(ll)==70
    hg={}
    for family in ['WITNESS','NATURAL','READ_HEAVY']:
        for variant in ['baseline','snapshot']:
            subset=[x for x in rr if x['family']==family and x['variant']==variant]
            hg[family+'_'+variant]={'runs':len(subset),'recalls':sum(int(x['recalls']) for x in subset),'direct_conflicts':sum(int(x['verified_raw_conflicts']) for x in subset),'excluded_order_only':sum(int(x['publication_order_only_TORN']) for x in subset),'terminal_C2':sum(x['final_C2']=='True' for x in subset)}
    assert hg['WITNESS_baseline']['direct_conflicts']==10 and hg['WITNESS_snapshot']['direct_conflicts']==0
    assert hg['NATURAL_baseline']['recalls']==2551 and hg['NATURAL_baseline']['direct_conflicts']==1
    assert hg['NATURAL_snapshot']['recalls']==2241 and hg['NATURAL_snapshot']['direct_conflicts']==0
    assert [hg['NATURAL_'+v]['excluded_order_only'] for v in ['baseline','snapshot']]==[54,128]
    assert all(sum(hg[f+'_'+v]['terminal_C2'] for f in ['WITNESS','NATURAL','READ_HEAVY'])==35 for v in ['baseline','snapshot'])
    result=json.loads((h/'RESULT.json').read_text());assert result['overhead_rule_passed'] is False
    assert math.isclose(result['no_write_p95_ratio_median'],1.2055616853922608)
    assert math.isclose(result['no_write_throughput_ratio_median'],.790152534581683)
    out={'pass':True,'table_IV':A,'table_V':B,'hindsight_counts':hg,'saved_hindsight_paired_ci':result['paired_whole_run_bootstrap_95'],'note':'Counts reconstructed; saved Hindsight bootstrap/cost result fields checked, not a new bootstrap.'}
    (r/'paper_map/PAPER_CHECK.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps({'pass':True,'table_IV_rows':len(A),'table_V_rows':len(B),'hindsight_runs':70,'figure2_run_values':200}))

if __name__=='__main__':main()
