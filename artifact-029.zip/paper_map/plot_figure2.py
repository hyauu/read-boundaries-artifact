from pathlib import Path
import csv, argparse
import matplotlib.pyplot as plt
import numpy as np
ap=argparse.ArgumentParser();ap.add_argument('--output',default='figure2_rebuilt.pdf');a=ap.parse_args()
rows=list(csv.DictReader((Path(__file__).parent/'figure2_all_200_runs.csv').open()))
groups=[('NONE','READ_ONLY'),('FORCED_FULL','spaced'),('FORCED_FULL','burst'),('DEFAULT_REQUEST','spaced'),('DEFAULT_REQUEST','burst')]
print('Available mode/stratum:',sorted(set((r['requested_mode'],r['stratum']) for r in rows)))
# Resolve recorded profile casing explicitly, retaining all 200 points.
keys=list(dict.fromkeys((r['requested_mode'],r['stratum']) for r in rows))
ro=[k for k in keys if 'read' in k[1].lower() or k[0] not in ['FORCED_FULL','DEFAULT_REQUEST']]
order=ro+sorted([k for k in keys if k not in ro],key=lambda k:(0 if k[0]=='FORCED_FULL' else 1,0 if 'spac' in k[1].lower() else 1))
policies=['NATIVE','DOUBLE_READ','COORDINATED','EPOCH_VALIDATED'];labels=['Unprotected','Double read','Gate','Epoch']
fig,ax=plt.subplots(figsize=(9,3));colors=['#444444','#d55e00','#0072b2','#009e73']
for j,policy in enumerate(policies):
 for i,key in enumerate(order):
  vals=np.array([float(r['delivered_ms_p95']) for r in rows if (r['requested_mode'],r['stratum'])==key and r['strategy']==policy]);assert len(vals)==10
  x=i+(j-1.5)*.17;q=np.quantile(vals,[.25,.5,.75])
  ax.scatter(x+np.linspace(-.035,.035,10),vals,s=12,color=colors[j],alpha=.65,label=labels[j] if i==0 else None)
  ax.errorbar(x,q[1],yerr=[[q[1]-q[0]],[q[2]-q[1]]],fmt='_',color=colors[j],capsize=3)
ax.set_yscale('log');ax.set_ylabel('Delivered recall p95 (ms)');ax.set_xticks(range(len(order)),[m+'\n'+s for m,s in order]);ax.legend(ncol=4,fontsize=8);fig.tight_layout();fig.savefig(a.output)
